
import Tkinter                                                             
                                                                           
# root                                                                     
root = Tkinter.Tk()                                                        
root.title("To Be Displayed on TV")                                                                          
# Create widgets                                                           
canvas = Tkinter.Canvas(root)                                              
canvas.grid(column=0, row=0)                                               
                                                                           
# Vertical scroll bar                                                      
#verticalScrollbar = Tkinter.Scrollbar(root)                                
#verticalScrollbar.grid(column=1, row=0,                                    
#    sticky=Tkinter.NS)                                                     
                                                                           
# Horizontal scroll bar                                                    
#horizontalScrollbar = Tkinter.Scrollbar(root)                              
#horizontalScrollbar.grid(column=0, row=1,                                  
#    sticky=Tkinter.EW)                                                     
                                                                           
# Configure                                                                
root.rowconfigure(0, weight=1)                                             
root.columnconfigure(0, weight=1)                                          
canvas.config(                                                             
    width = 640, height = 480, background = 'white',                       
    scrollregion = (0, 0, 127, 127)                                       
#    xscrollcommand=horizontalScrollbar.set,                                
#    yscrollcommand=verticalScrollbar.set
    )
#verticalScrollbar.config(                                                  
#    orient=Tkinter.VERTICAL,                                               
#    command = canvas.yview)                                                
#horizontalScrollbar.config(                                                
#    orient=Tkinter.HORIZONTAL,                                             
#    command = canvas.xview)                                                
                                                                           
# Draw on canvas
myimage = Tkinter.PhotoImage( file = "test.png" )

canvas.create_image(50,50, image=myimage)
#canvas.create_polygon(10, 10, 100, 50, 10, 100)                            
#canvas.pack()

root.update()                                                                       
root.mainloop()                                                            
                                                                           
# EOF                                                                      
