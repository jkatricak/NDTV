#for importing all of the tkinter stuff
from Tkinter import *
#import the program searchguide functionality
import searchpguide
import string
import os

#this is to store the channels I'm going to need to display
chnllist = []
buttonlist = []
onchannel = 0
dayoffset = 0
houroffset = 72
myresults = []
oldresults = []
focusvar = 0
sfocusvar=0
pors = "p"
cmdlist = []

def reportEvent(event):
    print event.keysym
    if event.keysym=='q':
        searchpguide.root.destroy()
    #if event.keysym=='a':
    #    for traverse in chnllist:
    #        traverse.destroy()
    #    chnllist = []
    global pors
    global sfocusvar
    
    if pors=="p": # in the program phase
        
        if event.keysym=="Up" or event.keysym=="Down" or event.keysym=="Left" or event.keysym=="Right":
            programchange(event.keysym)
        if event.keysym=="Return":
            pors="s"
            selectprogram()

    elif pors=="s":
        if event.keysym=="Left":
           sfocusvar=(sfocusvar-1)%len(buttonlist)
           buttonlist[sfocusvar].focus_set()
        elif event.keysym=="Right":
           sfocusvar=(sfocusvar+1)%len(buttonlist)
           buttonlist[sfocusvar].focus_set()
        elif event.keysym=="Return":
            sdecision()


#this reads in the selected command and then does it 
def sdecision():
    if cmdlist[sfocusvar]=="Back to Program Menu":
        programchange("Nothing")
        global pors
        global sfocusvar
        pors="p"
        sfocusvar=0
        
    print cmdlist[sfocusvar]

    # JIM'S STUFF-> YOU CAN ERASE IF YOU REALLY MUST
    #if cmdlist[sfocusvar] == "Season Pass On":
    #    print "HOWDY"

#This is for the secondary menu that displays info on the selected show and asks you what you want to do with it.  
def selectprogram():
        #destroy possible pre-existing stuff
        global chnllist
        global buttonlist
        global cmdlist
        #delete button info
        for traverse in buttonlist:
            traverse.destroy()
        buttonlist = []
        #delete frame info
        for traverse in chnllist:
            traverse.destroy()

        chnllist = []
        #Frame for Top part including Description and show info
        chnllist.append(Frame(searchpguide.root,borderwidth=1,relief=RIDGE))
        #display the title + SubTitle + channel etc frame
        f=Frame(chnllist[0],borderwidth=0,relief=FLAT) #Main frame for everything



        #*****************TITLE PLUS SUB TITLE**********************
        #Title Plus Sub Title Frame Info
        subf=Frame(f,borderwidth=2,relief=GROOVE) #Sub Frame for Individual title etc

        #Label For Data Being Displayed
        pieceframe=Frame(subf,borderwidth=2,width=100, height=100,relief=RIDGE)        
        Label(pieceframe,text="Title:",justify=LEFT, width=9).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2,fill=BOTH,expand=YES)
        
        #Display Actual Data
        pieceframe=Frame(subf,borderwidth=2,relief=GROOVE)        
        Label(pieceframe,text=oldresults[focusvar][0] + " - " + oldresults[focusvar][1],width=50,justify=LEFT).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2)        

        subf.pack(side=TOP,padx=2,pady=2)#Pack this frame for prog info stuff

        #*****************Category**********************
        #Title Plus Data
        subf=Frame(f,borderwidth=2,relief=GROOVE) #Sub Frame for Individual title etc
        #Label For Data Being Displayed
        pieceframe=Frame(subf,borderwidth=2,width=100, height=100,relief=RIDGE)        
        Label(pieceframe,text="Category:",justify=LEFT, width=9).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2,fill=BOTH,expand=YES)
        
        #Display Actual Data
        pieceframe=Frame(subf,borderwidth=2,relief=GROOVE)        
        Label(pieceframe,text=oldresults[focusvar][6],width=50,justify=LEFT).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2)        

        subf.pack(side=TOP,padx=2,pady=2)#Pack this frame for prog info stuff

        #*****************Channel**********************
        #Title Plus Data
        subf=Frame(f,borderwidth=2,relief=GROOVE) #Sub Frame for Individual title etc
        #Label For Data Being Displayed
        pieceframe=Frame(subf,borderwidth=2,width=100, height=100,relief=RIDGE)        
        Label(pieceframe,text="Channel:",justify=LEFT, width=9).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2,fill=BOTH,expand=YES)
        
        #Display Actual Data
        pieceframe=Frame(subf,borderwidth=2,relief=GROOVE)        
        Label(pieceframe,text=oldresults[focusvar][5],width=50,justify=LEFT).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2)        

        subf.pack(side=TOP,padx=2,pady=2)#Pack this frame for prog info stuff


        #*****************Start Time**********************
        #Title Plus Data
        subf=Frame(f,borderwidth=2,relief=GROOVE) #Sub Frame for Individual title etc
        #Label For Data Being Displayed
        pieceframe=Frame(subf,borderwidth=2,width=100, height=100,relief=RIDGE)        
        Label(pieceframe,text="Start:",justify=LEFT, width=9).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2,fill=BOTH,expand=YES)
        
        #Display Actual Data
        pieceframe=Frame(subf,borderwidth=2,relief=GROOVE)        
        Label(pieceframe,text="Day: %s-%s-%s Hour: %s:%s" % (oldresults[focusvar][3][4:6],oldresults[focusvar][3][6:8],oldresults[focusvar][3][0:4],oldresults[focusvar][3][8:10],oldresults[focusvar][3][10:12]),width=50,justify=LEFT).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2)        

        subf.pack(side=TOP,padx=2,pady=2)#Pack this frame for prog info stuff
        

        #*****************Start Time**********************
        #Title Plus Data
        subf=Frame(f,borderwidth=2,relief=GROOVE) #Sub Frame for Individual title etc
        #Label For Data Being Displayed
        pieceframe=Frame(subf,borderwidth=2,width=100, height=100,relief=RIDGE)        
        Label(pieceframe,text="End:",justify=LEFT, width=9).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2,fill=BOTH,expand=YES)
        
        #Display Actual Data
        pieceframe=Frame(subf,borderwidth=2,relief=GROOVE)        
        Label(pieceframe,text="Day: %s-%s-%s Hour: %s:%s" % (oldresults[focusvar][4][4:6],oldresults[focusvar][4][6:8],oldresults[focusvar][4][0:4],oldresults[focusvar][4][8:10],oldresults[focusvar][4][10:12]),width=50,justify=LEFT).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2)        

        subf.pack(side=TOP,padx=2,pady=2)#Pack this frame for prog info stuff

        
        #***********Pack whole show info other than description*****
        f.pack(side=LEFT,padx=2,pady=2)
        
        #*************display the Description**********8
        f=Frame(chnllist[0],borderwidth=2,relief=GROOVE)
        Label(f,text="Description: " + oldresults[focusvar][2],justify=LEFT,wraplength=300).pack(side=LEFT)
        f.pack(side=LEFT,padx=2,pady=2)



        #Frame for bottom part (Season Pass, Record Individual Etc)
        chnllist.append(Frame(searchpguide.root,borderwidth=1,relief=RIDGE))
        

        buttonlist = []

        #TEST FOR IF SHOW IS ALREADY ON SEASON PASS SCHEDULE
        if searchpguide.seasonpasscheck(oldresults[focusvar])==0:            
            #*******BUTTON FOR Turn on SEASON PASS****************
            mybutton=Button(chnllist[1],borderwidth=1,highlightthickness=3,relief=RAISED,bg="blue",justify="left")
            Label(mybutton,text="Turn on Season Pass",justify=LEFT,wraplength=300).pack(side=LEFT)
            mybutton.pack(side=LEFT)
            buttonlist.append(mybutton)
            cmdlist.append("Season Pass On")
        else:
             #*******BUTTON FOR Turn off SEASON PASS****************
            mybutton=Button(chnllist[1],borderwidth=1,highlightthickness=3,relief=RAISED,bg="blue",justify="left")
            Label(mybutton,text="Turn off Season Pass",justify=LEFT,wraplength=300).pack(side=LEFT)
            mybutton.pack(side=LEFT)           
            buttonlist.append(mybutton)
            cmdlist.append("Season Pass Off")

        #Test for determining if show is already scheduled to be recorded, because that determines which button they get.  
        if searchpguide.txtcolor(oldresults[focusvar])=="red":
            
             #*******BUTTON FOR Record Individual****************
             mybutton=Button(chnllist[1],borderwidth=1,highlightthickness=3,relief=RAISED,bg="blue",justify="left")
             Label(mybutton,text="Delete Scheduled Recording",justify=LEFT,wraplength=300).pack(side=LEFT)
             mybutton.pack(side=LEFT)
             buttonlist.append(mybutton)
             cmdlist.append("Delete Scheduled Recording")
            
        else:
            #*******BUTTON FOR Delete Record****************
            mybutton=Button(chnllist[1],borderwidth=1,highlightthickness=3,relief=RAISED,bg="blue",justify="left")
            Label(mybutton,text="Set To Record",justify=LEFT,wraplength=300).pack(side=LEFT)
            mybutton.pack(side=LEFT)
            buttonlist.append(mybutton)
            cmdlist.append("Set Scheduled Recording")

        mybutton=Button(chnllist[1],borderwidth=1,highlightthickness=3,relief=RAISED,bg="blue",justify="left")
        Label(mybutton,text="Back to Program Menu",justify=LEFT,wraplength=300).pack(side=LEFT)
        mybutton.pack(side=LEFT)
        buttonlist.append(mybutton)
        cmdlist.append("Back to Program Menu")
        
        
        for traverse in chnllist: #Pack up everything we've added
            traverse.pack()

        buttonlist[0].focus_set()

def programchange(input):
    #this is the channel we are currently displaying
    global onchannel
    global dayoffset
    global houroffset
    global myresults
    global focusvar
    global oldresults
    oldresults=myresults # for determining list changes you need to know where you were

    #check which one should be highlighted at the end, if <0 then need to change visible stuff
    if input!="Nothing":
        focusvar=searchpguide.inputresponse(input,myresults,oldresults,focusvar)
    
    if (focusvar<0 or input=="Nothing"):
        
        if input!="Nothing":
            focusvar=(focusvar*-1)-1 #reset focusvar to positive side
        #change viewable program stuff
        if input=='Left':
            houroffset=houroffset-1
        elif input=='Right':
            houroffset=houroffset+1
        elif input=='Up':
            onchannel=onchannel-1
        elif input=='Down':
            onchannel=onchannel+1

            #onchannel=string.atoi(myresults[0][5][:2])+1
        #destroy possible pre-existing stuff
        global chnllist
        global buttonlist
        #delete button info
        for traverse in buttonlist:
            traverse.destroy()
            buttonlist = []
        #delete frame info
        for traverse in chnllist:
            traverse.destroy()
            chnllist = []
            
            
        myresults = searchpguide.getprogramdata(dayoffset,houroffset,onchannel)
        maxlen=0
        maxtime=0


        #display relavent entries
        for traverse in myresults:
            #print "Start Time %s-%s %s:%s End Time %s-%s %s:%s start minute %s endminute %s Channel %s Show %s " % (traverse[3][4:6],traverse[3][6:8],traverse[3][8:10],traverse[3][10:12], traverse[4][4:6],traverse[4][6:8],traverse[4][8:10],traverse[4][10:12],traverse[8],traverse[10], traverse[5],traverse[0])
            #print "     Length(Minutes) %s" % (searchpguide.width(traverse)),
            #print " Genre %s " % (traverse[6])
            if len(traverse[0]) > maxlen:
                maxlen = len(traverse[0])
                maxlentime = searchpguide.width(traverse)

        if maxlen>30:
            maxlen=30
            maxlentime=30

        #**************For Input of keystrokes*****************
        searchpguide.root.bind_all('<KeyPress>',reportEvent)

        #**********display the relavent time information on the top FOR CHANNEL TIME*********
        chnllist.append(Frame(searchpguide.root,borderwidth=1,relief=RIDGE))
        #display the day on the left part
        f=Frame(chnllist[0],borderwidth=2,relief=GROOVE)
        Label(f,text=searchpguide.getday(dayoffset,houroffset),width=10).pack(side=LEFT)
        f.pack(side=LEFT,padx=2,pady=2)
        #display the hour information
        starthinfo = searchpguide.getstarthour(houroffset)
        i=0
        while i<4:
            if i%2==0:
                starthinfo=starthinfo+1
            if ((starthinfo-starthinfo%12)/12)%2==1:
                apm="PM"
            else:
                apm="AM"
            
            f=Frame(chnllist[0],borderwidth=2,relief=GROOVE)
            timeh = starthinfo
            timeh=timeh%12
            if timeh==0:
                timeh=12
            Label(f,text="%s:%s0 %s" %(timeh,(i%2)*3, apm),width=28).pack(side=LEFT)
            f.pack(side=LEFT,padx=.6,pady=0)
            i=i+1



        #puts the first frame on there
        chnllist.append(Frame(searchpguide.root,borderwidth=1,relief=RIDGE))

        #variables used internally while traversing all of the shows to display
        newchnl=1
        i=0

        #to display initial channel information
        f=Frame(chnllist[newchnl],borderwidth=2,relief=GROOVE)
        Label(f,text=myresults[i][5],width=10).pack(side=LEFT)
        f.pack(side=LEFT,padx=2,pady=2)
    
        #display all listing info
        for relief in myresults:
            #put listing info into it's own button
            f=Button(chnllist[newchnl],borderwidth=1,highlightthickness=3,relief=RAISED,bg=searchpguide.color(myresults[i][6]),justify="left")
            # I tweaked with the width thing a lot to try and make it look right, needs to be better
            tmpwidth=searchpguide.width(relief)
            padcount=2
            if tmpwidth<len(myresults[i][0]) and tmpwidth>3:
                Label(f,text=myresults[i][0][0:tmpwidth-3]+"...",width=searchpguide.width(relief)-padcount,bg=searchpguide.color(myresults[i][6]),fg=searchpguide.txtcolor(myresults[i])).pack(side=LEFT)
            elif tmpwidth<3:
                Label(f,text=".",width=tmpwidth-padcount,bg=searchpguide.color(myresults[i][6]),fg=searchpguide.txtcolor(myresults[i])).pack(side=RIGHT) 
            else:
                Label(f,text=myresults[i][0],width=searchpguide.width(relief)-padcount,bg=searchpguide.color(myresults[i][6]),fg=searchpguide.txtcolor(myresults[i])).pack(side=RIGHT)
            f.pack(side=LEFT,padx=0,pady=0)
            buttonlist.append(f)
            #if the next channel is different from the current channel put in a new space
            if i<len(myresults)-1:
                #double test needed to prevent seg fault at the end
                if myresults[i][5][:2]!=myresults[i+1][5][:2]:
                    #insert the new channel frame into it's own list to refer to later
                    chnllist.append(Frame(searchpguide.root,borderwidth=1,relief=RIDGE))
                    #this is for referencing the new channel frame when inserting shows
                    newchnl=newchnl+1
                    #this is for putting in the channel information into the new channel frame
                    f=Frame(chnllist[newchnl],borderwidth=2.0,relief=GROOVE)
                    Label(f,text=myresults[i+1][5],width=10).pack(side=LEFT)
                    f.pack(side=LEFT,padx=2,pady=2)
            i = i+1
    
          #actually pack up all of the channel frames to display them on the screen
        for traverse in chnllist:
            traverse.pack()
            
        if input!="Nothing":
            focusvar=searchpguide.inputresponse(input,myresults,oldresults,focusvar)
        #focusvar=0
        buttonlist[focusvar].focus_set()
        #focusvar=0





#********************************************************************
    else:
        #not changing viewable program stuff, just changing focus
        buttonlist[focusvar].focus_set()


#variables for displaying tk stuff
searchpguide.root=Tk()

#pull over initial database information
searchpguide.init_dbase()

#function to actually input and display everything
programchange("nothing")

#f.focus_set()
        

#run the program thingy
searchpguide.root.mainloop()

#        Label(f,text=myresults[i][0],width=((searchpguide.width(relief)-2)/2)).pack(side=LEFT)
