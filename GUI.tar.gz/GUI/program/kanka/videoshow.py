#for importing all of the tkinter stuff
from Tkinter import *
from tkSimpleDialog import Dialog
import tkMessageBox
#import the program searchguide functionality
import searchvideo
import string
import re
import MySQLdb

def color(item):
    if item=="News" or item=="Special":
        return "blue"
    elif item=="Sports":
        return "green"
    elif item=="Action":
        return "red"
    elif item=="Soaps" or item=="Reality":
        return "powder blue"
    elif item=="Doc" or item=="Edu":
        return "misty rose"
    elif item=="Health" or item=="Travel":
        return "azure"
    elif item=="Comedy":
        return "yellow"
    elif item=="Talk":
        return "purple"
    elif item=="Children's":
        return "hot pink"
    elif item=="How-To" or item=="Cooking":
        return "coral"
    elif item=="SciFi" or item=="Mystery":
        return "lime green"
    elif item=="Drama" or item=="Crime":
        return "orange"
    elif item=="Shopping" or item=="Collectibles":
        return "aquamarine"
    else:
        return "ForestGreen"


#variables for displaying tk stuff
root=Tk()

#this is to store the stuff I'm going to need to display
testashow = []
buttonlist = []
showlist = []

mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
#create a cursor
    
cursor = mydb.cursor()

#tells the database to give you listings in "video"
cursor.execute("SELECT * FROM " + "video")
#load the resultset
resultset = cursor.fetchall()

def reportEvent(event):
    print event.keysym
    if event.keysym=='q':
        root.destroy()

global resultsframe
resultsframe = Frame(root)
#inputpattern = tkSimpleDialog.askstring(None, "Search String: ")

def showsearch(input):
    global buttonlist
    
    for traverse2 in buttonlist:
        traverse2.destroy()
    buttonlist=[]
    
    #display relevent entries
    for traverse in resultset:
        pattern = ent.get()
        if input=="nothing":
            matchobj = re.search(pattern, traverse[0])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input=="title":
            matchobj = re.search(pattern, traverse[0])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        #elif input=="sub":
            #matchobj = re.search(pattern, traverse[1])
            #if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        #elif input=="time":
            #matchobj = re.search(pattern, traverse[3])
            #if matchobj:
                #testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input=="genre":
            matchobj = re.search(pattern, traverse[6])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()
            
    #testashow.sort(lambda x,y: (cmp(x[0],y[0])))
    testashow.sort(lambda x,y: (cmp(x[3],y[3])))

    if input=='1':
        testashow.sort(lambda x,y: (cmp(x[3],y[3])))
    if input=='2':
        testashow.sort(lambda x,y: (cmp(x[0],y[0])))
    if input=='3':
        testashow.sort(lambda x,y: (cmp(x[5],y[5])))
    if input=='4':
        testashow.sort(lambda x,y: (cmp(x[6],y[6])))
            
    #**************For Input of keystrokes*****************
    root.bind_all('<KeyPress>',reportEvent)

    #variables used internally while traversing all of the shows to display
    i=0
    #display all listing info
    while i<len(testashow) and i<25:
        #put listing info into it's own button
        showbutton = Button(resultsframe,relief=RAISED,
                          bg=color(testashow[i][6]))
        Label(showbutton,text=testashow[i][5]+" "+testashow[i][0]+
              " "+testashow[i][1],bg=color(testashow[i][6]),
              width=60).pack(side=LEFT)
        showbutton.pack(side=TOP,padx=0,pady=0,anchor=NW)
        buttonlist.append(showbutton)
        i = i+1

    resultsframe.pack(side=RIGHT,anchor=NE)

    x=0
    print len(testashow)


    while x<len(testashow):
        #print x
        #print len(testashow)
        del testashow[x]

variables = []

leftframe = Frame(root)
searchframe = Frame(leftframe)
searchbtnframe = Frame(leftframe)

lab = Label(searchframe,width=20,text='Type pattern here: ')
lab.pack(side=LEFT,anchor=NW)
ent = Entry(searchframe)
ent.pack(side=LEFT,anchor=NW)

var = StringVar()
ent.config(textvariable=var)
variables.append(var)


sortframe = Frame(leftframe)
sortbtnframe = Frame(sortframe)

MODES = [
    ("Time", "1"),
    ("Title", "2"),
    ("Channel", "3"),
    ("Genre", "4"),
    ]
                  
v = StringVar()
v.set("1") # initialize

rdlab = Label(sortframe,width=30,text='Sort results by, or browse by: ')
rdlab.pack(side=LEFT,anchor=NW)

def onPress():
    pick = v.get()
    print 'Input => "%s"' % ent.get()
    print 'you pressed', pick
    showsearch(pick)
                  
for text, mode in MODES:
    rdbtn = Radiobutton(sortbtnframe,text=text,command=onPress,
                        variable=v,value=mode)
    rdbtn.pack(side=TOP,anchor=NW)

def fetch():
    print 'Input => "%s"' % ent.get()
    showsearch("nothing")

def fetchsub():
    print 'Input => "%s"' % ent.get()
    showsearch("sub")

def fetchtime():
    print 'Input => "%s"' % ent.get()
    showsearch("time")

def fetchgenre():
    print 'Input => "%s"' % ent.get()
    showsearch("genre")


ent.focus()
ent.bind('<Return>',(lambda event: fetch()))
btn = Button(searchbtnframe,text='Search for Title',command=fetch)
btn.pack(side=TOP,anchor=NW,fill=X)
btn = Button(searchbtnframe,text='Search by Subtitle',command=fetchsub)
btn.pack(side=TOP,anchor=NW,fill=X)
btn = Button(searchbtnframe,text='Search by Time',command=fetchtime)
btn.pack(side=TOP,anchor=NW,fill=X)
btn = Button(searchbtnframe,text='Search by Genre',command=fetchgenre)
btn.pack(side=TOP,anchor=NW,fill=X)
newvar = StringVar()


searchframe.pack(side=TOP,anchor=NW)
searchbtnframe.pack(side=TOP,anchor=NE)
sortbtnframe.pack(side=TOP,anchor=NW)
sortframe.pack(side=TOP,anchor=NW)
leftframe.pack(side=LEFT,anchor=NW)

#run the program thingy
root.mainloop()
