#for importing the mysql database
import MySQLdb
#for useful string manipulations
import string

#used to store info on the root
global root

global resultset
global audio
 
def init_dbase():
    global resultset
    global audio

    #Connect to the Database
    mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
    #create a cursor
    cursor = mydb.cursor()

    #Load audio
    cursor.execute("SELECT * FROM " + "audio")
    audio=cursor.fetchall()

    #load the resultset
    resultset = cursor.fetchall()    

#returns list of what your searching for
def getprogramdata(title,artist,genre):
    global resultset
    global audio

    rent=[]
    for traverse in resultset:
        rent.append(traverse)
        complete.append(traverse)


def color(item):
    if item=="News" or item=="Special":
        return "blue"
    elif item=="Sports":
        return "green"
    elif item=="Action":
        return "red"
    elif item=="Soaps" or item=="Reality":
        return "powder blue"
    elif item=="Doc" or item=="Edu":
        return "misty rose"
    elif item=="Health" or item=="Travel":
        return "azure"
    elif item=="Comedy":
        return "yellow"
    elif item=="Talk":
        return "purple"
    elif item=="Children's":
        return "hot pink"
    elif item=="How-To" or item=="Cooking":
        return "coral"
    elif item=="SciFi" or item=="Mystery":
        return "lime green"
    elif item=="Drama" or item=="Crime":
        return "orange"
    elif item=="Shopping" or item=="Collectibles":
        return "aquamarine"
    else:
        return "ForestGreen"
           
def inputresponse(input, currentlist, oldlist, current):
    #Test for starting display, where you're not supposed to display anything.
    if input=="nothing":
        return -1

    if oldlist!=currentlist: #This is the case for where the program menu has changed it's display from the last time, so figuring out the focus may be difficult
        

        #The Person wants to go right and the display has changed
        if input=="Right":
            oldendtime=oldlist[current][10]+2 #find the new start time that is one minute past the old end time
            oldchannel=oldlist[current][5] #make sure it's the correct channel
            i=0
            for traverse in currentlist:
                if traverse[5]==oldchannel and traverse[8]<=oldendtime<=traverse[10]:
                    return i
                i=i+1

            if i>=len(currentlist): #special case for display change, but displaying same show
                i=0
                for traverse in currentlist:
                    if traverse[5]==oldchannel and traverse[8]<=oldendtime-2<=traverse[10]:
                        return i
                    i=i+1
                    
                
        if input=="Left":
            oldendtime=oldlist[current][8]-2 #find the new start time that is one minute past the old end time
            oldchannel=oldlist[current][5] #make sure it's the correct channel
            i=0
            for traverse in currentlist:
                if traverse[5]==oldchannel and traverse[8]<=oldendtime<=traverse[10]:
                    return i
                i=i+1

            if i>=len(currentlist): #special case for display change, but displaying same show
                i=0
                for traverse in currentlist:
                    if traverse[5]==oldchannel and traverse[8]<=oldendtime+2<=traverse[10]:
                        return i
                    i=i+1

        if input=="Down":
            oldendtime=oldlist[current][8]+1


            i=0
            for traverse in channels:
               if traverse==oldlist[current][5]:
                   oldchannel=channels[i+1] #Advance to next channel cuz down
               i=i+1

            i=0
            for traverse in currentlist:
                if traverse[5]==oldchannel and traverse[8]<=oldendtime<=traverse[10]:
               
                    return i
                i=i+1            
        if input=="Up":
            oldendtime=oldlist[current][8]+1

            i=0
            for traverse in channels:
               if traverse==oldlist[current][5]:
                   oldchannel=channels[i-1] #Advance to previous channel cuz up
               i=i+1

            i=0
            for traverse in currentlist:
                if traverse[5]==oldchannel and traverse[8]<=oldendtime<=traverse[10]:
                    return i
                i=i+1       
        return 0

    
    if input=="Down": # ****************************DOWN*****************
        i=current%len(oldlist)

        if current+1>=len(oldlist):
            return (current+1)*-1             
        
        while oldlist[i][5]==oldlist[i+1][5] and i+2<len(oldlist): #while next channel in list is same as the current channel
            i=i+1
        i=i+1
        if i+2>len(oldlist):
            return (current+1)*-1
        
        #Find show one down similar start time
        while oldlist[current][8]>oldlist[i][8] and oldlist[i][5]==oldlist[i+1][5]:
            #Test for if end of list
            if i+1>=len(oldlist):
                return (current+1)*-1
            #increment
            i=i+1
        #print "i is %s len is %s" % (i,len(oldlist))
        return i


    
    elif input=="Up": #**********************************UP****************

        if current==0: #special case for if at start of list
            return (current+1)*-1   

        i=current
        while oldlist[i][5]==oldlist[i-1][5] and i-1>0: #while next channel in list is same as the current channel
            i=i-1
        i=i-1
        if i-1<0:
            return (current+1)*-1
        if i==0:
            return i
        
        #Find show one down similar start time
        while oldlist[current][8]<oldlist[i][8] and oldlist[i][5]==oldlist[i-1][5]:
            #Test for if end of list
            if i-1<0:
                return (current+1)*-1
            #increment
            i=i-1
        #print "i is %s len is %s" % (i,len(oldlist))
        return i



    elif input=="Right": #************************RIGHT********************
        if current+1>=len(oldlist): #We know at's at the end of the list and needs to display a new one
            return (current+1)*-1

        if oldlist[current][5]!=oldlist[current+1][5]:
            return (current+1)*-1
        else:
            return current+1
    elif input=="Left": #*********************************LEFT***********
        if current==0: #It's at the start of the list so we know it needs to go left
            return (current+1)*-1
        
        if oldlist[current][5]!=oldlist[current-1][5]:
            return (current+1)*-1
        else:
            return current-1    
    


    return current
