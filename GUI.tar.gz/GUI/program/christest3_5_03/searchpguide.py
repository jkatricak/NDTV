#for importing the function to know the local time
import time
#for importing the mysql database
import MySQLdb
#for useful string manipulations
import string

#this is for the width program to truncate the length if the program goes past the current menu

#ending hour for listing being displayed
global endhour

#returns width in minutes
def width(program):

    #program ending time
    progend=string.atoi(program[4][11:13])
    
    #print "endhour %s progend %s" % (endhour, progend)
    #testing for if the program ends in the hour were showing
    if endhour > progend:
        width = string.atoi(program[4][11:13])-string.atoi(program[3][11:13])
        width = width * 60
        width = width + string.atoi(program[4][14:16])-string.atoi(program[3][14:16])
    #testing for if the program doesnt ending on the hour if it ends at the begining of the next
    elif string.atoi(program[4][14:16])==0:
        width = string.atoi(program[4][11:13])-string.atoi(program[3][11:13])
        width = width * 60
        width = width + string.atoi(program[4][14:16])-string.atoi(program[3][14:16])
    #program does not end in the viwed time so it needs to be truncated
    else:
        width = string.atoi(program[4][11:13])-string.atoi(program[3][11:13])
        width = width * 60
        width = width -string.atoi(program[3][14:16])

        width = endhour - string.atoi(program[3][11:13])
        width = width * 60
        width = width - string.atoi(program[3][14:16])        
    
    return width
    

#returns list of what your searching for
def getprogramdata(aday,ahour,channel):
    #this is the function to get the local time it's in a list
    mytime = time.localtime()

    #to make sure the portions have a 2 length char ("02" not "2")
    month="%s" % (mytime[1])
    if len("%s" % (mytime[1]))==1:
        month="0%s" % (mytime[1])
    day="%s" % (mytime[2]+aday)
    if len("%s" % (mytime[2]+aday))==1:
        day="0%s" % (mytime[2]+aday)
    ihour=mytime[3]+ahour
    hour="%s" % (mytime[3]+ahour)
    if len("%s" % (mytime[3]+ahour))==1:
        hour="0%s" % (mytime[3]+ahour)
    iminute=mytime[4]
    minute="%s" % (mytime[4])
    if len("%s" % (mytime[4]))==1:
        minute="0%s" % (mytime[4])
        
    day="%s-%s-%s" % (mytime[0],month,day)

    #this variable sets up the number of hours we want to return the results for
    hourswanted=1
    #for width program to truncate the listing
    global endhour
    endhour=hourswanted+ihour+1

    #Connect to the Database
    mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
    #create a cursor
    
    cursor = mydb.cursor()

    #tells the database to give you all of the programme data
    cursor.execute("SELECT * FROM " + "programme")
    #load the resultset
    resultset = cursor.fetchall()

    #pull out relavent program data for our day
    #filter out actual channels to save
    rent=[]
    for traverse in resultset:
        #check for if on correct day
        if traverse[3][:-9]==day:
            if ihour<=string.atoi(traverse[3][11:13])<=ihour+hourswanted:
                rent.append(traverse)


    #***** Filter time according to channels we're interested in****
    #this is the starting value for how many channels it will search for
    chnlcount=0;
    chnlstart=channel
    chnlend=channel-1

    i=0
    test = 1

    #find span of channels were insterested in
    #this variable is the number of different channels we want to return
    numchtoret = 8
    while chnlcount<numchtoret and chnlend<1000:
        chnlend=chnlend+1
        #print chnlend
        test=1
        for traverse in rent:
            if test and chnlend==string.atoi(traverse[5][:2]):
                # found the next highest channel
                chnlcount = chnlcount + 1
                test=0
                
    #filter time by channels were interested in 
    returnme = []

    i=chnlstart
    while i<chnlend:        
        for traverse in rent:
            if i==string.atoi(traverse[5][:2]):
                returnme.append(traverse)
        i=i+1

    return returnme

def color(item):
    if item=="News" or item=="Special":
        return "blue"
    elif item=="Sports":
        return "green"
    elif item=="Action":
        return "red"
    elif item=="Soaps" or item=="Reality":
        return "powder blue"
    elif item=="Doc" or item=="Edu":
        return "misty rose"
    elif item=="Health" or item=="Travel":
        return "azure"
    elif item=="Comedy":
        return "yellow"
    elif item=="Talk":
        return "purple"
    elif item=="Children's":
        return "hot pink"
    elif item=="How-To" or item=="Cooking":
        return "coral"
    elif item=="SciFi" or item=="Mystery":
        return "lime green"
    elif item=="Drama" or item=="Crime":
        return "orange"
    elif item=="Shopping" or item=="Collectibles":
        return "aquamarine"
    else:
        return "ForestGreen"

def getday(offset):
    mytime = time.localtime()
    return "%s/%s/%s" % (mytime[1],mytime[2]+offset,mytime[0])

def getstarthour(offset):
    mytime=time.localtime()
    return mytime[3]+offset
