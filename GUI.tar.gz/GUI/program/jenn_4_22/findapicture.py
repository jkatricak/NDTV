#for importing all of the tkinter stuff
from Tkinter import *
from tkSimpleDialog import Dialog
import tkMessageBox
#import the program searchguide functionality
import searchpguide
import string
import re
import MySQLdb
import os

def color(item):
    #CHANGE THIS TO COLOR BY FORMAT!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    if item=="jpeg" or "jpg":
        return "blue"
    elif item=="bmp":
        return "green"
    elif item=="gif":
        return "red"
    elif item=="ppm":
        return "yellow"
    elif item=="tiff":
        return "orange"
    else:
        return "ForestGreen"


#this is to store the stuff I'm going to need to display
biglist = []
testashow = []
buttonlist = []
newbuttonlist = []
timelist = []
showlist = []
chnllist = []
focusvar = 0
sfocusvar = 0
pors = "p"   # in search phase
cmdlist = []
searchvar = "nothing"
global root
global ent
global v
global stringsearch
global resultsframe
global bigtimeframe

mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
#create a cursor
    
cursor = mydb.cursor()

#tells the database to give you all of the programme data
cursor.execute("SELECT * FROM " + "pictures")
#load the resultset
resultset = cursor.fetchall()


def search_input(key):
    if key=="Up" or key=="Down" or key=="F1" or key=="F2" or key=="F3" or key=="F4" or key=="F5" or key=="F6" or key=="F7" or key=="F8":
        if key=="Down":
            keyinput("Down")
        if key=="Up":
            keyinput("Up")
        if key=="F1":
            fetch()
        if key=="F2":
            fetchname()
        if key=="F3":
            fetchformat()
        if key=="F4":
            fetchdim()
        if key=="F5":
            showsearch(searchvar,'1')
        if key=="F6":
            showsearch(searchvar,'2')
        if key=="F7":
            showsearch(searchvar,'3')
        if key=="F8":
            showsearch(searchvar,'4')
        return "Continue"
    if key=="Return":
        tmpreturn = []
        tmpreturn.append("GotoFunc")
        tmpreturn.append("picture_select")
        tmpreturn.append(" ")
        return tmpreturn

    return "Continue"

def search_return(frame, argument):
    global root
    root=frame
    if argument=="GoBack":
        global cmdlist
        global pors
        global sfocusvar
        pors = "p"
        sfocusvar = 0
        cmdlist = []
    init_search(root," ")
    showsearch(searchvar,v)
    
            

def searchselect_input(key):
    global sfocusvar
    global newbuttonlist
    if key=="Left":
        sfocusvar=(sfocusvar-1)%len(newbuttonlist)
        newbuttonlist[sfocusvar].focus_set()
    if key=="Right":
        sfocusvar=(sfocusvar+1)%len(newbuttonlist)
        newbuttonlist[sfocusvar].focus_set()
    if key=="Return":
        return sdecision()
    return "Continue"


# Begin From Chris's code!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

def sdecision():
    if cmdlist[sfocusvar]=="Back to Program Menu":
        #showsearch(searchvar,v)
        global pors
        global sfocusvar
        global cmdlist
        pors = "p"
        sfocusvar = 0
        
        cmdlist = []
        tmpreturn = []
        tmpreturn.append("Done")
        tmpreturn.append(" ")
        tmpreturn.append("Nothing")
        return tmpreturn
        
        
    elif cmdlist[sfocusvar] == "View Picture":
        #Set to Record
        tmp = os.system("mplayer -fs %s" %
                        (testashow[focusvar][7]))
        print "-%s-" % (tmp)
        #Re-init dbase cuz of changes
        searchpguide.init_dbase()
        #Go Back to Program Menu Now
        #showsearch(searchvar,v)
        global pors
        global sfocusvar
        global cmdlist
        pors = "p"
        sfocusvar = 0
        
        cmdlist = []
        tmpreturn = []
        tmpreturn.append("Done")
        tmpreturn.append(" ")
        tmpreturn.append("Nothing")
        return tmpreturn

        
    print cmdlist[sfocusvar]
    cmdlist = []



#This is for the secondary menu that displays info on the selected show and asks you what you want to do with it.  
def init_search_select(frameref,arguments):
        #destroy possible pre-existing stuff
        global chnllist
        global newbuttonlist
        global cmdlist
        global root

        root=frameref
        
        #delete button info
        for traverse in newbuttonlist:
            traverse.destroy()
        newbuttonlist = []
        #delete frame info
        for traverse in chnllist:
            traverse.destroy()

        chnllist = []
        #Frame for Top part including Description and show info
        chnllist.append(Frame(root,borderwidth=1,relief=RIDGE))
        #display the title + SubTitle + channel etc frame
        f=Frame(chnllist[0],borderwidth=0,relief=FLAT)


        #*****************TITLE PLUS SUB TITLE**********************
        #Title Plus Sub Title Frame Info
        subf=Frame(f,borderwidth=2,relief=GROOVE) #Sub Frame

        #Label For Data Being Displayed
        pieceframe=Frame(subf,borderwidth=2,width=100,height=100,relief=RIDGE)
        Label(pieceframe,text="Title:",justify=LEFT,bg="coral",
              width=9).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2,fill=BOTH,expand=YES)
        
        #Display Actual Data
        pieceframe=Frame(subf,borderwidth=2,relief=GROOVE)        
        Label(pieceframe,text=testashow[focusvar][0]+" - "+
              testashow[focusvar][1],width=50,justify=LEFT).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2)        

        subf.pack(side=TOP,padx=2,pady=2)#Pack this frame for prog info stuff


        #*****************Category**********************
        #Title Plus Data
        subf=Frame(f,borderwidth=2,relief=GROOVE) #Sub Frame
        
        #Label For Data Being Displayed
        pieceframe=Frame(subf,borderwidth=2,width=100,height=100,relief=RIDGE)
        Label(pieceframe,text="Category:",justify=LEFT, bg="coral",
              width=9).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2,fill=BOTH,expand=YES)
        
        #Display Actual Data
        pieceframe=Frame(subf,borderwidth=2,relief=GROOVE)        
        Label(pieceframe,text=testashow[focusvar][6],
              bg=searchpguide.color(testashow[focusvar][6]),width=50,
              justify=LEFT).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2)        

        subf.pack(side=TOP,padx=2,pady=2)#Pack this frame for prog info stuff


        #*****************Channel**********************
        #Title Plus Data
        subf=Frame(f,borderwidth=2,relief=GROOVE) #Sub Frame
        
        #Label For Data Being Displayed
        pieceframe=Frame(subf,borderwidth=2,width=100,height=100,relief=RIDGE) 
        Label(pieceframe,text="Channel:",justify=LEFT, bg="coral",
              width=9).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2,fill=BOTH,expand=YES)
        
        #Display Actual Data
        pieceframe=Frame(subf,borderwidth=2,relief=GROOVE)        
        Label(pieceframe,text=testashow[focusvar][5],width=50,
              justify=LEFT).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2)        

        subf.pack(side=TOP,padx=2,pady=2)#Pack this frame for prog info stuff


        #*****************Start Time**********************
        #Title Plus Data
        subf=Frame(f,borderwidth=2,relief=GROOVE) #Sub Frame
        #Label For Data Being Displayed
        pieceframe=Frame(subf,borderwidth=2,width=100, height=100,relief=RIDGE)        
        Label(pieceframe,text="Start:",justify=LEFT,bg="coral",
              width=9).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2,fill=BOTH,expand=YES)
        
        #Display Actual Data
        pieceframe=Frame(subf,borderwidth=2,relief=GROOVE)        
        Label(pieceframe,text="Day: %s-%s-%s Hour: %s:%s" %
              (testashow[focusvar][3][4:6],testashow[focusvar][3][6:8],
               testashow[focusvar][3][0:4],testashow[focusvar][3][8:10],
               testashow[focusvar][3][10:12]),width=50,
              justify=LEFT).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2)        

        subf.pack(side=TOP,padx=2,pady=2)#Pack this frame for prog info stuff
        

        #*****************Start Time**********************
        #Title Plus Data
        subf=Frame(f,borderwidth=2,relief=GROOVE) #Sub Frame
        #Label For Data Being Displayed
        pieceframe=Frame(subf,borderwidth=2,width=100,height=100,relief=RIDGE)    
        Label(pieceframe,text="End:",justify=LEFT,bg="coral",
              width=9).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2,fill=BOTH,expand=YES)
        
        #Display Actual Data
        pieceframe=Frame(subf,borderwidth=2,relief=GROOVE)        
        Label(pieceframe,text="Day: %s-%s-%s Hour: %s:%s" %
              (testashow[focusvar][4][4:6],testashow[focusvar][4][6:8],
               testashow[focusvar][4][0:4],testashow[focusvar][4][8:10],
               testashow[focusvar][4][10:12]),width=50,
              justify=LEFT).pack(side=LEFT)
        pieceframe.pack(side=LEFT,padx=2,pady=2)        

        subf.pack(side=TOP,padx=2,pady=2)#Pack this frame for prog info stuff

        
        #***********Pack whole show info other than description*****
        f.pack(side=TOP,padx=2,pady=2)
        
        #*************Display the Description**********8
        f=Frame(chnllist[0],borderwidth=2,relief=GROOVE)
        Label(f,text="Description: " + testashow[focusvar][2],
              justify=LEFT,wraplength=300).pack(side=LEFT)
        f.pack(side=TOP,padx=2,pady=2)


        #Frame for bottom part (Season Pass, Record Individual Etc)
        chnllist.append(Frame(root,borderwidth=1,relief=RIDGE))

        newbuttonlist = []

        mybutton=Button(chnllist[1],borderwidth=5,highlightthickness=5,
                        relief=RAISED,bg="blue",justify="left")
        Label(mybutton,text="View Picture",justify=LEFT,
              wraplength=300).pack(side=LEFT)
        mybutton.pack(side=LEFT,padx=5)
        newbuttonlist.append(mybutton)
        cmdlist.append("View Picture")

        mybutton=Button(chnllist[1],borderwidth=5,highlightthickness=5,
                        relief=RAISED,bg="blue",justify="left")
        Label(mybutton,text="Back to Program Menu",justify=LEFT,
              wraplength=300).pack(side=LEFT)
        mybutton.pack(side=LEFT,padx=5)
        newbuttonlist.append(mybutton)
        cmdlist.append("Back to Program Menu")
        
        
        for traverse in chnllist: #Pack up everything we've added
            traverse.pack(pady=40)

        newbuttonlist[0].focus_set()


# End From Chris's code!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



def showsearch(input1, input2):

    x=0
    while x<len(testashow):
        #print x
        #print len(testashow)
        del testashow[x]

    global biglist
    global buttonlist
    global timelist
    global focusvar
    
    for traverse2 in buttonlist:
        traverse2.destroy()
    buttonlist=[]

    for traverse3 in timelist:
        traverse3.destroy()
    timelist=[]

    for traverse in biglist:
        traverse.destroy()
    biglist=[]
    
    #display relavent entries
    for traverse in resultset:
        pattern = stringsearch
        if input1=="nothing":
            matchobj = re.search(pattern, traverse[0])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="description":
            matchobj = re.search(pattern, traverse[0])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="filename":
            matchobj = re.search(pattern, traverse[2])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="format":
            matchobj = re.search(pattern, traverse[3])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="dim":
            matchobj = re.search(pattern, traverse[1])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()
            
    #testashow.sort(lambda x,y: (cmp(x[0],y[0])))
    testashow.sort(lambda x,y: (cmp(x[1],y[1])))

    if input2=='1':
        testashow.sort(lambda x,y: (cmp(x[0],y[0])))
    if input2=='2':
        testashow.sort(lambda x,y: (cmp(x[2],y[2])))
    if input2=='3':
        testashow.sort(lambda x,y: (cmp(x[3],y[3])))
    if input2=='4':
        testashow.sort(lambda x,y: (cmp(x[1],y[1])))
            
    #**************For Input of keystrokes*****************
    
    resultsframe = Frame(root)
    bigtimeframe = Frame(root)

    #variables used internally while traversing all of the shows to display
    i=0
    #display all listing info
    while i<len(testashow) and i<25:
        #put listing info into it's own button
        showbutton = Button(resultsframe,relief=RAISED,
                          bg=color(testashow[i][6]))
        Label(showbutton,text=testashow[i][2]+", "+testashow[i][0],
              bg=color(testashow[i][3]),
              width=60).pack(side=LEFT)
        timeframe = Frame(bigtimeframe,borderwidth=2,relief=GROOVE)
        Label(timeframe,text=testashow[i][1],
              justify=LEFT,width=18).pack(side=LEFT)
        showbutton.pack(side=TOP,padx=0,pady=0,anchor=NW)
        timeframe.pack(side=TOP,padx=1,pady=1,anchor=NE)
        buttonlist.append(showbutton)
        timelist.append(timeframe)
        i = i+1

    biglist.append(bigtimeframe)
    biglist.append(resultsframe)

    bigtimeframe.pack(side=RIGHT,anchor=NE)
    resultsframe.pack(side=RIGHT,anchor=NE)

    print len(buttonlist)

    if len(buttonlist) > 0:
        buttonlist[0].focus_set()
        focusvar = 0

    print len(testashow)


def keyinput(input):
    global buttonlist
    global focusvar

    if input=="Down":
        buttonlist[focusvar+1].focus_set()
        focusvar = focusvar+1
        print focusvar

    if input=="Up":
        buttonlist[focusvar-1].focus_set()
        focusvar = focusvar-1
        print focusvar        


def fetch():
    print 'Input => "%s"' % ent.get()
    global stringsearch
    stringsearch = ent.get()
    global searchvar
    searchvar = "description"
    showsearch("description", 0)

def fetchname():
    print 'Input => "%s"' % ent.get()
    global stringsearch
    stringsearch = ent.get()
    global searchvar
    searchvar = "filename"
    showsearch("filename", 0)

def fetchformat():
    print 'Input => "%s"' % ent.get()
    global stringsearch
    stringsearch = ent.get()
    global searchvar
    searchvar = "format"
    showsearch("format", 0)

def fetchdim():
    print 'Input => "%s"' % ent.get()
    global stringsearch
    stringsearch = ent.get()
    global searchvar
    searchvar = "dim"
    showsearch("dim", 0)

def onPress():
    pick = v.get()
    print 'Input2 => "%s"' % ent.get()
    global stringsearch
    stringsearch = ent.get()
    print 'you pressed', pick
    print searchvar
    showsearch(searchvar, pick)
                  

def init_search(myframe,arguments):
    global root
    root=myframe
    
    searchpguide.init_dbase()

    variables = []

    leftframe = Frame(root)
    searchframe = Frame(leftframe)
    searchbtnframe = Frame(leftframe)
    
    lab = Label(searchframe,width=16,text='Type pattern here: ')
    lab.pack(side=LEFT,anchor=NW)
    global ent
    ent = Entry(searchframe)
    ent.pack(side=LEFT,anchor=NW)
    
    var = StringVar()
    ent.config(textvariable=var)
    variables.append(var)
    
    
    sortframe = Frame(leftframe)
    sortbtnframe = Frame(sortframe)
    
    MODES = [
        ("Description", "1"),
        ("Filename", "2"),
        ("Format", "3"),
        ("Dimensions", "4"),
        ]

    global v
    v = StringVar()
    v.set("1") # initialize
    
    rdlab = Label(sortframe,width=26,text='Sort results by, or browse by: ')
    rdlab.pack(side=LEFT,anchor=NW)

    for text, mode in MODES:
        rdbtn = Radiobutton(sortbtnframe,text=text,command=onPress,
                            variable=v,value=mode)
        rdbtn.pack(side=TOP,anchor=NW)
    
    btn = Button(searchbtnframe,text='Search for Description',command=fetch)
    btn.pack(side=TOP,anchor=NW,fill=X)
    btn = Button(searchbtnframe,text='Search by Filename',command=fetchname)
    btn.pack(side=TOP,anchor=NW,fill=X)
    btn = Button(searchbtnframe,text='Search by Format',command=fetchformat)
    btn.pack(side=TOP,anchor=NW,fill=X)
    btn = Button(searchbtnframe,text='Search by Dimensions',command=fetchdim)
    btn.pack(side=TOP,anchor=NW,fill=X)
    newvar = StringVar()
    
    searchframe.pack(side=TOP,anchor=NW)
    searchbtnframe.pack(side=TOP,anchor=NE)
    sortbtnframe.pack(side=TOP,anchor=NW)
    sortframe.pack(side=TOP,anchor=NW)
    leftframe.pack(side=LEFT,anchor=NW)
    
    ent.focus()
    ent.bind('<F1>',(lambda event: fetch()))
    ent.bind('<F2>',(lambda event: fetchname()))
    ent.bind('<F3>',(lambda event: fetchformat()))
    ent.bind('<F4>',(lambda event: fetchdim()))
    ent.bind('<F5>',(lambda event: showsearch(searchvar,'1')))
    ent.bind('<F6>',(lambda event: showsearch(searchvar,'2')))
    ent.bind('<F7>',(lambda event: showsearch(searchvar,'3')))
    ent.bind('<F8>',(lambda event: showsearch(searchvar,'4')))

#run the program thingy
#root.mainloop()
