#for importing all of the tkinter stuff
from Tkinter import *
import sys
sys.path.append("/home/ndtv/GUI/functions/script")
sys.path.append("/home/ndtv/GUI/functions/program")
###################
sys.path.append("/home/ndtv/GUI/master/jdir")
sys.path.append("/home/ndtv/GUI/program/jenn_4_22")
import setupscrn
###################
import os #JPK

import menudemo
import program
import findashow
import findasong
import findavideo
import findapicture
import bcradio #JPK
import ripcd #JPK

#This is for a reference for which txt means which function to call
# "script" - this is for the scriptable higher level menu stuff
# "program" - this is for the view schedule menu
# "prog_select" - this is for once a program has been selected from the view schedule menu

global functionlist
global masterroot
global currentframe
####################
global recSettings
#default setting is medium JPK
recSettings = [[0, 1, 0], [0, 1, 0], [1, 0, 0], [0, 0, 0], [0, 0, 0]]
####################
global bitrate #for CD ripping JPK
functionlist = [] #This list is to store what functions to call
functionlist.append("script") #for the initial call

def reportEvent(event): # for analyzing keyboard input and then passing it onto a given function where appropriate
    global functionlist

    ########################################################
    global recSettings
    global currentframe
    ########################################################
    
    if event.keysym=="q": # For Quitting the application in FWM
        global masterroot
        masterroot.destroy()
        return

    if event.keysym=="BackSpace": #For the Go Back one Button
        goback()
        return
        
    

    print event.keysym
    print len(functionlist)-1
    
    if functionlist[len(functionlist)-1]=="script":
        print "Pass info to script"
        result = menudemo.keyinput(event.keysym)
        print result
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
    ###############################################################
    elif functionlist[len(functionlist)-1]=="setupscreen":      
        result = setupscrn.keyinput(event.keysym, recSettings)
        recSettings = result[1]
        currentframe.destroy() 
        currentframe = Frame(masterroot,borderwidth=1,relief=FLAT)
        setupscrn.init_setupmod(currentframe,recSettings)
        currentframe.pack()
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
    ###############################################################

    #JPK
    elif functionlist[len(functionlist)-1]=="bcradio":
        result = bcradio.keyinput(event.keysym)
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])

    #JPK
    elif functionlist[len(functionlist)-1]=="ripcd":      
        result = ripcd.keyinput(event.keysym)
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
            
    elif functionlist[len(functionlist)-1]=="program":
        result = program.program_input(event.keysym)
        print result
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
    elif functionlist[len(functionlist)-1]=="prog_select":
        result=program.progselect_input(event.keysym)
        print " Result is %s" % (result)
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])

    elif functionlist[len(functionlist)-1]=="findashow":
        result = findashow.search_input(event.keysym)
        print result
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
    elif functionlist[len(functionlist)-1]=="search_select":
        result=findashow.searchselect_input(event.keysym)
        print " Result is %s" % (result)
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
    elif functionlist[len(functionlist)-1]=="findasong":
        result = findasong.search_input(event.keysym)
        print result
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
    elif functionlist[len(functionlist)-1]=="song_select":
        result=findasong.searchselect_input(event.keysym)
        print " Result is %s" % (result)
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])

    elif functionlist[len(functionlist)-1]=="findavideo":
        result = findavideo.search_input(event.keysym)
        print result
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
    elif functionlist[len(functionlist)-1]=="video_select":
        result=findavideo.searchselect_input(event.keysym)
        print " Result is %s" % (result)
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])

    elif functionlist[len(functionlist)-1]=="findapicture":
        result = findapicture.search_input(event.keysym)
        print result
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
    elif functionlist[len(functionlist)-1]=="picture_select":
        result=findapicture.searchselect_input(event.keysym)
        print " Result is %s" % (result)
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])

                              
    else:
        print "Unknown function call attempted"
        print functionlist[len(functionlist)-1]

def goback(): # This function is for the automated go back button.  So you can always go back one menu.
    if len(functionlist)>1:

        global currentframe
        global functionlist
        currentframe.destroy() # need to erase whats there right now, because we will be passing a new frame to the next function
        currentframe = Frame(masterroot,borderwidth=1,relief=FLAT)
        global functionlist
        functionlist = functionlist[0:-1]
        print "Go Back to lower function %s " % (functionlist[-1])

        if functionlist[-1]=="program":
            program.program_return(currentframe,"GoBack")

        elif functionlist[-1]=="findashow":
            findashow.search_return(currentframe,"GoBack")

        elif functionlist[-1]=="findasong":
            findasong.search_return(currentframe,"GoBack")

        elif functionlist[-1]=="findavideo":
            findavideo.search_return(currentframe,"GoBack")

        elif functionlist[-1]=="findapicture":
            findapicture.search_return(currentframe,"GoBack")

        elif functionlist[-1]=="script":
            tmpargpass = []
            tmpargpass.append("GoBack")
            menudemo.init_script(currentframe,tmpargpass)            


        currentframe.pack()


        
def returncontrol(status, nextfunc, argument): # This is for a function to return control and then either add a new function to the list, or return to the lower level stuff.  
    print "status is %s" % (status)
    global currentframe
    global functionlist
    
    ################################################################
    global recSettings
    ################################################################
    global bitrate #JPK
    
    if status=="Done": #Returns control to the lower level
        print "Done Going to lower function"
        currentframe.destroy() # need to erase whats there right now, because we will be passing a new frame to the next function
        currentframe = Frame(masterroot,borderwidth=1,relief=FLAT)
        global functionlist
        functionlist = functionlist[0:-1]
        if functionlist[-1]=="program":
            program.program_return(currentframe,argument)
        elif functionlist[-1]=="findashow":
            findashow.search_return(currentframe,argument)
        elif functionlist[-1]=="findasong":
            findasong.search_return(currentframe,argument)
        elif functionlist[-1]=="findavideo":
            findavideo.search_return(currentframe,argument)
        elif functionlist[-1]=="findapicture":
            findapicture.search_return(currentframe,argument)
        elif functionlist[-1]=="script":
            tmpargpass = []
            tmpargpass.append("GoBack")
            menudemo.init_script(currentframe,tmpargpass)
            
        currentframe.pack()

    elif status=="GotoFunc":
        print "Goto Function %s" % (nextfunc)
        currentframe.destroy() # need to erase whats there right now, because we will be passing a new frame to the next function
        currentframe = Frame(masterroot,borderwidth=1,relief=FLAT)

        if nextfunc=="script":
            functionlist.append("script")
            menudemo.init_script(currentframe,argument)

        #######################################################################
        elif nextfunc == "setupscreen":
            functionlist.append("setupscreen")
            setupscrn.init_setupmod(currentframe,recSettings)
        ########################################################################    
        elif nextfunc=="program":
            functionlist.append("program")
            program.init_program(currentframe,argument)
        elif nextfunc=="prog_select":
            functionlist.append("prog_select")
            program.init_prog_select(currentframe,argument)


        elif nextfunc=="findashow":
            functionlist.append("findashow")
            findashow.init_search(currentframe,argument)
        elif nextfunc=="search_select":
            functionlist.append("search_select")
            findashow.init_search_select(currentframe,argument)

        elif nextfunc=="findasong":
            functionlist.append("findasong")
            findasong.init_search(currentframe,argument)
        elif nextfunc=="song_select":
            functionlist.append("song_select")
            findasong.init_search_select(currentframe,argument)

        elif nextfunc=="findavideo":
            functionlist.append("findavideo")
            findavideo.init_search(currentframe,argument)
        elif nextfunc=="video_select":
            functionlist.append("video_select")
            findavideo.init_search_select(currentframe,argument)

        elif nextfunc=="findapicture":
            functionlist.append("findapicture")
            findapicture.init_search(currentframe,argument)
        elif nextfunc=="picture_select":
            functionlist.append("picture_select")
            findapicture.init_search_select(currentframe,argument)
            

        #JPK
        elif nextfunc=="tvon":
            functionlist.append("tvon")
            #turn on tv
            os.system("/ndtv/scripts/ndtv_tv &")
            #return to previous menu
            goback()
        #JPK
        elif nextfunc=="playdvd":
            functionlist.append("playdvd")
            #play dvd
            os.system("/ndtv/scripts/ndtv_dvd &")
            #return to previous menu
            goback()
        #JPK
        elif nextfunc=="playcd":
            functionlist.append("playcd")
            #open xmms to play cd
            os.system("xmms /mnt/cdrom &")
            #return to previous menu
            goback()
        #JPK
        elif nextfunc=="bcradio":
            functionlist.append("bcradio")
            bcradio.init_bcradio(currentframe)
        #JPK
        elif nextfunc=="ripcd":
            functionlist.append("ripcd")
            if recSettings[0][0] == 1:
                #low quality, bitrate = 96
                os.system("/home/ndtv/DBGroup/ripit.pl --bitrate 96")
                ripcd.init_ripcd(currentframe,96)
            elif recSettings[0][1] == 1:
                #medium quality, bitrate = 160
                os.system("/home/ndtv/DBGroup/ripit.pl --bitrate 160")
                ripcd.init_ripcd(currentframe,160)
            elif recSettings[0][2] == 1:
                #high quality, bitrate = 320
                os.system("/home/ndtv/DBGroup/ripit.pl --bitrate 320")
                ripcd.init_ripcd(currentframe,320)
            

        currentframe.pack()

        
masterroot = Tk() # This is the actual Root reference.  No function should ever get to see this!

currentframe = Frame(masterroot,borderwidth=1,relief=FLAT)

#**************For Input of keystrokes*****************
masterroot.bind_all('<KeyPress>',reportEvent)

w = masterroot.winfo_screenwidth()
h = masterroot.winfo_screenheight()
masterroot.overrideredirect(0)
masterroot.geometry("%dx%d+0+0" % (w, h))

tmpargpass = []
tmpargpass.append("/home/ndtv/GUI/functions/script/menudemo/mediavideo.setup")
returncontrol("GotoFunc","script",tmpargpass)

#menudemo.init_script(masterroot,tmpargpass)




masterroot.mainloop() # Start running it

