#for importing all of the tkinter stuff
from Tkinter import *
#import the program searchguide functionality
import searchpguide

#this is the channel we are currently displaying
onchannel=1

myresults = searchpguide.getprogramdata(1,1,onchannel)
maxlen=0
maxtime=0

#print myresults

#display relavent entries
for traverse in myresults:
    print "Start Time %s End Time %s Channel %s Show %s" % (traverse[3], traverse[4], traverse[5],traverse[0])
    print searchpguide.width(traverse)
    print traverse[6]
    if len(traverse[0]) > maxlen:
        maxlen = len(traverse[0])
        maxlentime = searchpguide.width(traverse)

print maxlen
print maxlentime

if maxlen>30:
    maxlen=30
    maxlentime=30

#variables for displaying tk stuff
root=Tk()

#this is to store the six channels I'm going to need to display
chnllist = []

chnllist.append(Frame(root,borderwidth=1,relief=RIDGE))

#variables used internally while traversing all of the shows to display
newchnl=0
i=0

#to display initial channel information
f=Frame(chnllist[newchnl],borderwidth=2,relief=GROOVE)
Label(f,text=myresults[i][5],width=10).pack(side=LEFT)
f.pack(side=LEFT,padx=2,pady=2)
    
#display all listing info
for relief in myresults:
    #put listing info into it's own button
    if myresults[i][6]=="News" or myresults[i][6]=="Special":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="blue",justify="left")
    elif myresults[i][6]=="Sports":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="green",justify="left")
    elif myresults[i][6]=="Action":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="red",justify="left")
    elif myresults[i][6]=="Soaps" or myresults[i][6]=="Reality":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="powder blue",justify="left")
    elif myresults[i][6]=="Doc" or myresults[i][6]=="Edu":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="misty rose",justify="left")
    elif myresults[i][6]=="Health" or myresults[i][6]=="Travel":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="azure",justify="left")
    elif myresults[i][6]=="Comedy":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="yellow",justify="left")
    elif myresults[i][6]=="Talk":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="purple",justify="left")
    elif myresults[i][6]=="Children's":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="hot pink",justify="left")
    elif myresults[i][6]=="How-To" or myresults[i][6]=="Cooking":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="coral",justify="left")
    elif myresults[i][6]=="SciFi" or myresults[i][6]=="Mystery":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="lime green",justify="left")
    elif myresults[i][6]=="Drama" or myresults[i][6]=="Crime":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="orange",justify="left")
    elif myresults[i][6]=="Shopping" or myresults[i][6]=="Collectibles":
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg="aquamarine",justify="left")
    else:
        f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,justify="left")
    # I tweaked with the width thing a lot to try and make it look right, needs to be better
    if searchpguide.width(relief)>maxlentime:
        factor=searchpguide.width(relief)/maxlentime
        factor2=1
        if myresults[i][6]=="News" or myresults[i][6]=="Special":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="blue").pack(side=LEFT)
        elif myresults[i][6]=="Sports":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="green").pack(side=LEFT)
        elif myresults[i][6]=="Action":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="red").pack(side=LEFT)
        elif myresults[i][6]=="Soaps" or myresults[i][6]=="Reality":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="powder blue").pack(side=LEFT)
        elif myresults[i][6]=="Doc" or myresults[i][6]=="Edu":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="misty rose").pack(side=LEFT)
        elif myresults[i][6]=="Health" or myresults[i][6]=="Travel":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="azure").pack(side=LEFT)
        elif myresults[i][6]=="Comedy":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="yellow").pack(side=LEFT)
        elif myresults[i][6]=="Talk":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="purple").pack(side=LEFT)
        elif myresults[i][6]=="Children's":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="hot pink").pack(side=LEFT)
        elif myresults[i][6]=="How-To" or myresults[i][6]=="Cooking":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="coral").pack(side=LEFT)
        elif myresults[i][6]=="SciFi" or myresults[i][6]=="Mystery":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="lime green").pack(side=LEFT)
        elif myresults[i][6]=="Drama" or myresults[i][6]=="Crime":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="orange").pack(side=LEFT)
        elif myresults[i][6]=="Shopping" or myresults[i][6]=="Collectibles":
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2,bg="aquamarine").pack(side=LEFT)
        else:
            Label(f,text=myresults[i][0],width=(maxlen*factor)+factor2).pack(side=LEFT)
        f.pack(side=LEFT,padx=1.45,pady=0)
    else:
        if myresults[i][6]=="News" or myresults[i][6]=="Special":
            Label(f,text=myresults[i][0],width=maxlen,bg="blue").pack(side=LEFT)
        elif myresults[i][6]=="Sports":
            Label(f,text=myresults[i][0],width=maxlen,bg="green").pack(side=LEFT)
        elif myresults[i][6]=="Action":
            Label(f,text=myresults[i][0],width=maxlen,bg="red").pack(side=LEFT)
        elif myresults[i][6]=="Soaps" or myresults[i][6]=="Reality":
            Label(f,text=myresults[i][0],width=maxlen,bg="powder blue").pack(side=LEFT)
        elif myresults[i][6]=="Doc" or myresults[i][6]=="Edu":
            Label(f,text=myresults[i][0],width=maxlen,bg="misty rose").pack(side=LEFT)
        elif myresults[i][6]=="Health" or myresults[i][6]=="Travel":
            Label(f,text=myresults[i][0],width=maxlen,bg="azure").pack(side=LEFT)
        elif myresults[i][6]=="Comedy":
            Label(f,text=myresults[i][0],width=maxlen,bg="yellow").pack(side=LEFT)
        elif myresults[i][6]=="Talk":
            Label(f,text=myresults[i][0],width=maxlen,bg="purple").pack(side=LEFT)
        elif myresults[i][6]=="Children's":
            Label(f,text=myresults[i][0],width=maxlen,bg="hot pink").pack(side=LEFT)
        elif myresults[i][6]=="How-To" or myresults[i][6]=="Cooking":
            Label(f,text=myresults[i][0],width=maxlen,bg="coral").pack(side=LEFT)
        elif myresults[i][6]=="SciFi" or myresults[i][6]=="Mystery":
            Label(f,text=myresults[i][0],width=maxlen,bg="lime green").pack(side=LEFT)
        elif myresults[i][6]=="Drama" or myresults[i][6]=="Crime":
            Label(f,text=myresults[i][0],width=maxlen,bg="orange").pack(side=LEFT)
        elif myresults[i][6]=="Shopping" or myresults[i][6]=="Collectibles":
            Label(f,text=myresults[i][0],width=maxlen,bg="aquamarine").pack(side=LEFT)
        else:
            Label(f,text=myresults[i][0],width=maxlen).pack(side=LEFT)
        f.pack(side=LEFT,padx=0,pady=0)
    #if the next channel is different from the current channel put in a new space
    if i<len(myresults)-1:
        #double test needed to prevent seg fault at the end
        if myresults[i][5][:2]!=myresults[i+1][5][:2]:
            #insert the new channel frame into it's own list to refer to later
            chnllist.append(Frame(root,borderwidth=1,relief=RIDGE))
            #this is for referencing the new channel frame when inserting shows
            newchnl=newchnl+1
            #this is for putting in the channel information into the new channel frame
            f=Frame(chnllist[newchnl],borderwidth=2.0,relief=GROOVE)
            Label(f,text=myresults[i+1][5],width=10).pack(side=LEFT)
            f.pack(side=LEFT,padx=2,pady=2)
    i = i+1
    
#actually pack up all of the channel frames to display them on the screen
for traverse in chnllist:
    traverse.pack()

f.focus_set()
        

#run the program thingy
root.mainloop()

#        Label(f,text=myresults[i][0],width=((searchpguide.width(relief)-2)/2)).pack(side=LEFT)
