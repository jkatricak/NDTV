#for importing the function to know the local time
import time
#for importing the mysql database
import MySQLdb
#for useful string manipulations
import string

#used to store info on the root
global root

#this is for the width program to truncate the length if the program goes past the current menu

#ending hour for listing being displayed
global endhour
global starthour

#returns width in minutes
def width(program):

    #program ending hour
    progend=string.atoi(program[4][11:13])
    progendmin=string.atoi(program[4][14:16])
    progstarthour=string.atoi(program[3][11:13])
    progstartminute=string.atoi(program[3][14:16])

    if endhour>24 :
        #Program Display Runs Across two days
        if program[3][:-9]!=program[4][:-9]:
            #program itself runs across two days
            #test for if runs over allotted length
            if endhour%24<=progend:
                progend=endhour%24
                progendmin=0
                
            #test if under allotted time
            if starthour>progstarthour:
                progstarthour=starthour
                progstartminute=0
            
            #calc in hour for width
            width=(progend-progstarthour)*60
            width=width+progendmin-progstartminute
            width=width+24*60

        else:
            #program itself does not run across two days
                       #test for if runs over allotted length
            #print "starthour %s progstarthour %s" % (starthour, progstarthour)
            if endhour<=progend:
                progend=endhour
                progendmin=0

            if progend<10 and endhour%24 <=progend:
                progend=endhour%24
                progendmin=0

            #test if under allotted time
            if starthour>progstarthour and progstarthour>10:
                progstarthour=starthour
                progstartminute=0

            #calc in hour for width
            width=(progend-progstarthour)*60
            width=width+progendmin-progstartminute
 
    else:
        #Program Display does not Run Across Two Days
        if program[3][:-9]!=program[4][:-9]:
            #program itself runs across two days
                        #test for if runs over allotted length

            #RESET variables to work better for our cirumstances
            if endhour>24:
                progend=progend+24

            if endhour<=progend:
                progend=endhour
                progendmin=0

            if progend<12 and endhour>12:
                progend=endhour
                progendmin=0

            
            #test if under allotted time
            if progstarthour>12 and starthour<12:
                progstarthour=starthour
                progstartminute=0
                
            if starthour>progstarthour:
                progstarthour=starthour
                progstartminute=0
            
            #calc in hour for width
            width=(progend-progstarthour)*60
            width=width+progendmin-progstartminute
            
        else:
            #program itself does not run across two days

            #test for if runs over allotted length
            if endhour<=progend:
                progend=endhour
                progendmin=0
                
            #test if under allotted time
            if starthour>progstarthour:
                progstarthour=starthour
                progstartminute=0
            
            #calc in hour for width
            width=(progend-progstarthour)*60
            width=width+progendmin-progstartminute

            
    #print "end hour %s minute %s start hour %s minute %s width %s" % (progend, progendmin,progstarthour,progstartminute,width)

    return width
        

#returns list of what your searching for
def getprogramdata(aday,ahour,channel):
    #this is the function to get the local time it's in a list
    mytime = time.localtime()

    day=mytime[2]+aday
    ihour=mytime[3]+ahour
    #to make sure hour doesnt go over allotted amount
    day=day +(ihour-ihour%24)/24
    ihour=ihour%24
    
    #to make sure the portions have a 2 length char ("02" not "2")
    month="%s" % (mytime[1])
    if len("%s" % (mytime[1]))==1:
        month="0%s" % (mytime[1])

    if len("%s" % (day))==1:
        day="0%s" % (mytime[2]+aday)
    else:
        day="%s" % (day)
    

    if len("%s" % (ihour))==1:
        hour="0%s" % (ihour)
    else:
        hour="%s" % (ihour)        

    iminute=mytime[4]
    minute="%s" % (mytime[4])
    if len("%s" % (mytime[4]))==1:
        minute="0%s" % (mytime[4])
        
    day="%s-%s-%s" % (mytime[0],month,day)

    #this variable sets up the number of hours we want to return the results for
    hourswanted=2
    #for width program to truncate the listing
    global endhour
    global starthour
    endhour=hourswanted+ihour
    starthour=ihour
    
    #Connect to the Database
    mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
    #create a cursor
    
    cursor = mydb.cursor()

    #tells the database to give you all of the programme data
    cursor.execute("SELECT * FROM " + "programme")
    #load the resultset
    resultset = cursor.fetchall()

    #pull out relavent program data for our day
    #filter out actual channels to save
    rent=[]
    for traverse in resultset:
        #check for if on correct day and is same day
        if traverse[3][:-9]==day or traverse[4][:-9]==day:
            if ihour<=string.atoi(traverse[3][11:13])<ihour+hourswanted and traverse[3][:-9]==day :
                rent.append(traverse)
            elif ihour<=string.atoi(traverse[4][11:13])<ihour+hourswanted and traverse[4][:-9]==day:
                if ihour==string.atoi(traverse[4][11:13]):
                    if string.atoi(traverse[4][14:16])!=0:
                        rent.append(traverse)
                else:
                    rent.append(traverse)
        #check for if correct day different day (day goes over)
        if endhour>24:
            if string.atoi(traverse[3][8:10])==string.atoi(day[8:10])+1:
                if 0<=string.atoi(traverse[3][11:13])<endhour%24 :
                    rent.append(traverse)


    #***** Filter time according to channels we're interested in****
    #this is the starting value for how many channels it will search for
    chnlcount=0;
    chnlstart=channel
    chnlend=channel+1

    i=0
    test = 1

    #find span of channels were insterested in
    #this variable is the number of different channels we want to return
    numchtoret = 8
    while chnlcount<numchtoret and chnlend<1000:
        chnlend=chnlend+1
        #print chnlend
        test=1
        for traverse in rent:
            if test and chnlend==string.atoi(traverse[5][:2]):
                # found the next highest channel
                chnlcount = chnlcount + 1
                test=0
                
    #filter time by channels were interested in 
    returnme = []
    complete = []
    sortedstuff = []

    i=chnlstart

    while i<chnlend:        
        for traverse in rent:
            if i==string.atoi(traverse[5][:2]):
                complete.append(traverse)
        i=i+1

    #parse list by channels and put into channel sorted list
    tmp = []
    i=0
    
    for traverse in complete:
        tmp.append(traverse)
        if i<len(complete)-1:
            #double test needed to prevent seg fault at the end
            if complete[i][5][:2]!=complete[i+1][5][:2]:
                sortedstuff.append(tmp)
                tmp = []
        i=i+1

    #Sort within each channel for by start time
    for traverse in sortedstuff:
        traverse.sort(lambda x,y: (cmp(x[3],y[3])))
        
    #put out of double list back into single list and return
    for traverse in sortedstuff:
        for trav2 in traverse:
            returnme.append(trav2)

    return returnme

def color(item):
    if item=="News" or item=="Special":
        return "blue"
    elif item=="Sports":
        return "green"
    elif item=="Action":
        return "red"
    elif item=="Soaps" or item=="Reality":
        return "powder blue"
    elif item=="Doc" or item=="Edu":
        return "misty rose"
    elif item=="Health" or item=="Travel":
        return "azure"
    elif item=="Comedy":
        return "yellow"
    elif item=="Talk":
        return "purple"
    elif item=="Children's":
        return "hot pink"
    elif item=="How-To" or item=="Cooking":
        return "coral"
    elif item=="SciFi" or item=="Mystery":
        return "lime green"
    elif item=="Drama" or item=="Crime":
        return "orange"
    elif item=="Shopping" or item=="Collectibles":
        return "aquamarine"
    else:
        return "ForestGreen"

def getday(offset):
    mytime = time.localtime()
    return "%s/%s/%s" % (mytime[1],mytime[2]+offset,mytime[0])

def getstarthour(offset):
    mytime=time.localtime()
    return mytime[3]+offset
