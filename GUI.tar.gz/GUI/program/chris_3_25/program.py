#for importing all of the tkinter stuff
from Tkinter import *
#import the program searchguide functionality
import searchpguide
import string

#this is to store the channels I'm going to need to display
chnllist = []
buttonlist = []
onchannel = 0
dayoffset = 0
houroffset = 72
myresults = []
oldresults = []
focusvar = 0

def reportEvent(event):
    print event.keysym
    if event.keysym=='q':
        searchpguide.root.destroy()
    #if event.keysym=='a':
    #    for traverse in chnllist:
    #        traverse.destroy()
    #    chnllist = []
    programchange(event.keysym)

def programchange(input):
    #this is the channel we are currently displaying
    global onchannel
    global dayoffset
    global houroffset
    global myresults
    global focusvar
    global oldresults
    oldresults=myresults # for determining list changes you need to know where you were

    #check which one should be highlighted at the end, if <0 then need to change visible stuff
    focusvar=searchpguide.inputresponse(input,myresults,oldresults,focusvar)
    
    if (focusvar<0):
        
        focusvar=(focusvar*-1)-1 #reset focusvar to positive side
        #change viewable program stuff
        if input=='Left':
            houroffset=houroffset-1
        elif input=='Right':
            houroffset=houroffset+1
        elif input=='Up':
            #FIGURE OUT UP ISSUE
            1+1
        elif input=='Down':
            onchannel=string.atoi(myresults[0][5][:2])+1
        #destroy possible pre-existing stuff
        global chnllist
        global buttonlist
        #delete button info
        for traverse in buttonlist:
            traverse.destroy()
            buttonlist = []
        #delete frame info
        for traverse in chnllist:
            traverse.destroy()
            chnllist = []
            
            
        myresults = searchpguide.getprogramdata(dayoffset,houroffset,onchannel)
        maxlen=0
        maxtime=0


        #display relavent entries
        for traverse in myresults:
            print "Start Time %s-%s %s:%s End Time %s-%s %s:%s start minute %s endminute %s Channel %s Show %s " % (traverse[3][4:6],traverse[3][6:8],traverse[3][8:10],traverse[3][10:12], traverse[4][4:6],traverse[4][6:8],traverse[4][8:10],traverse[4][10:12],traverse[8],traverse[10], traverse[5],traverse[0])
            print "     Length(Minutes) %s" % (searchpguide.width(traverse)),
            print " Genre %s " % (traverse[6])
            if len(traverse[0]) > maxlen:
                maxlen = len(traverse[0])
                maxlentime = searchpguide.width(traverse)

        if maxlen>30:
            maxlen=30
            maxlentime=30

        #**************For Input of keystrokes*****************
        searchpguide.root.bind_all('<KeyPress>',reportEvent)

        #**********display the relavent time information on the top FOR CHANNEL TIME*********
        chnllist.append(Frame(searchpguide.root,borderwidth=1,relief=RIDGE))
        #display the day on the left part
        f=Frame(chnllist[0],borderwidth=2,relief=GROOVE)
        Label(f,text=searchpguide.getday(dayoffset,houroffset),width=10).pack(side=LEFT)
        f.pack(side=LEFT,padx=2,pady=2)
        #display the hour information
        starthinfo = searchpguide.getstarthour(houroffset)
        i=0
        while i<4:
            if i%2==0:
                starthinfo=starthinfo+1
                if ((starthinfo-starthinfo%12)/12)%2==1:
                    apm="PM"
            else:
                apm="AM"
            
            f=Frame(chnllist[0],borderwidth=2,relief=GROOVE)
            timeh = starthinfo
            timeh=timeh%12
            if timeh==0:
                timeh=12
            Label(f,text="%s:%s0 %s" %(timeh,(i%2)*3, apm),width=28).pack(side=LEFT)
            f.pack(side=LEFT,padx=.6,pady=0)
            i=i+1



        #puts the first frame on there
        chnllist.append(Frame(searchpguide.root,borderwidth=1,relief=RIDGE))

        #variables used internally while traversing all of the shows to display
        newchnl=1
        i=0

        #to display initial channel information
        f=Frame(chnllist[newchnl],borderwidth=2,relief=GROOVE)
        Label(f,text=myresults[i][5],width=10).pack(side=LEFT)
        f.pack(side=LEFT,padx=2,pady=2)
    
        #display all listing info
        for relief in myresults:
            #put listing info into it's own button
            f=Button(chnllist[newchnl],borderwidth=1,highlightthickness=3,relief=RAISED,bg=searchpguide.color(myresults[i][6]),justify="left")
            # I tweaked with the width thing a lot to try and make it look right, needs to be better
            tmpwidth=searchpguide.width(relief)
            padcount=2
            if tmpwidth<len(myresults[i][0]) and tmpwidth>3:
                Label(f,text=myresults[i][0][0:tmpwidth-3]+"...",width=searchpguide.width(relief)-padcount,bg=searchpguide.color(myresults[i][6]),fg=searchpguide.txtcolor(myresults[i])).pack(side=LEFT)
            elif tmpwidth<3:
                Label(f,text=".",width=tmpwidth-padcount,bg=searchpguide.color(myresults[i][6]),fg=searchpguide.txtcolor(myresults[i])).pack(side=RIGHT) 
            else:
                Label(f,text=myresults[i][0],width=searchpguide.width(relief)-padcount,bg=searchpguide.color(myresults[i][6]),fg=searchpguide.txtcolor(myresults[i])).pack(side=RIGHT)
            f.pack(side=LEFT,padx=0,pady=0)
            buttonlist.append(f)
            #if the next channel is different from the current channel put in a new space
            if i<len(myresults)-1:
                #double test needed to prevent seg fault at the end
                if myresults[i][5][:2]!=myresults[i+1][5][:2]:
                    #insert the new channel frame into it's own list to refer to later
                    chnllist.append(Frame(searchpguide.root,borderwidth=1,relief=RIDGE))
                    #this is for referencing the new channel frame when inserting shows
                    newchnl=newchnl+1
                    #this is for putting in the channel information into the new channel frame
                    f=Frame(chnllist[newchnl],borderwidth=2.0,relief=GROOVE)
                    Label(f,text=myresults[i+1][5],width=10).pack(side=LEFT)
                    f.pack(side=LEFT,padx=2,pady=2)
            i = i+1
    
          #actually pack up all of the channel frames to display them on the screen
        for traverse in chnllist:
            traverse.pack()
        buttonlist[focusvar].focus_set()
        focusvar=0





#********************************************************************
    else:
        #not changing viewable program stuff, just changing focus
        buttonlist[focusvar].focus_set()


#variables for displaying tk stuff
searchpguide.root=Tk()
#function to actually input and display everything
programchange("nothing")

#f.focus_set()
        

#run the program thingy
searchpguide.root.mainloop()

#        Label(f,text=myresults[i][0],width=((searchpguide.width(relief)-2)/2)).pack(side=LEFT)
