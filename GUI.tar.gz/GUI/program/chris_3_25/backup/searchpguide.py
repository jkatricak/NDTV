#for importing the function to know the local time
import time
#for importing the mysql database
import MySQLdb
#for useful string manipulations
import string

#used to store info on the root
global root

#this is for the width program to truncate the length if the program goes past the current menu

#ending hour for listing being displayed
global endhour
global starthour
global torec

#returns width in minutes
def width(program):
    global endhour
    global starthour
    #print "endmin %s startmin %s" % (endhour*60,starthour*60)
    
    endmin=program[10]
    startmin=program[8]

    if endmin>endhour*60:
        endmin=endhour*60

    if startmin<starthour*60:
        startmin=starthour*60
            
    #print "program title %s end hour %s minute %s start hour %s minute %s width %s % startday" % (program[0],program[9],program[10],program[7],program[8],program[10]-program[8],program[3])

    return endmin-startmin
        

#returns list of what your searching for
def getprogramdata(aday,ahour,channel):

    #this is the function to get the local time it's in a list
    mytime = time.localtime()

    #to figure out how many days have passed thus far
    month=mytime[1]
    if month==1:
        days=0
    elif month==2:
        days=31
    elif month==3:
        days=59
    elif month==4:
        days=90        
    elif month==5:
        days=120
    elif month==6:
        days=151
    elif month==7:
        days=181
    elif month==8:
        days=212
    elif month==9:
        days=243
    elif month==10:
        days=273
    elif month==11:
        days=304        
    elif month==12:
        days=334
        
    days=days+mytime[2] + aday
    print days,
    print "days so far"

    #calculates number of hours thus far including the offset
    hours=24*days + mytime[3] + ahour

    print "Hours so Far",
    print hours

    print "Minutes so far",
    print hours*60

    #this variable sets up the number of hours we want to return the results for
    hourswanted=2
    #for width program to truncate the listing

    global endhour
    global starthour
    global torec
    endhour=hourswanted+hours
    starthour=hours
    
    #Connect to the Database
    mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
    #create a cursor
    cursor = mydb.cursor()

    #Load Recorded TV data
    cursor.execute("SELECT * FROM " + "torecord")
    torec=cursor.fetchall()

    #tells the database to give you all of the programme data
    cursor.execute("SELECT * FROM " + "programme")

    #load the resultset
    resultset = cursor.fetchall()

    #pull out relavent program data for our day
    #filter out actual channels to save
    rent=[]
    for traverse in resultset:
        #check for if on correct day and is same day
        if (starthour*60<=(traverse[8])<endhour*60) or (starthour*60<(traverse[10])<=endhour*60):
            rent.append(traverse)

    #print rent

    #***** Filter time according to channels we're interested in****
    #this is the starting value for how many channels it will search for
    chnlcount=0;
    chnlstart=channel
    chnlend=channel;+1
    
    i=0
    test = 1

    #find span of channels were insterested in
    #this variable is the number of different channels we want to return
    numchtoret = 8
    while chnlcount<numchtoret and chnlend<1000:
        chnlend=chnlend+1
        #print chnlend
        test=1
        for traverse in rent:
            if test and chnlend==string.atoi(traverse[5][:2]):
                # found the next highest channel
                chnlcount = chnlcount + 1
                test=0
                
    #filter time by channels were interested in 
    returnme = []
    complete = []
    sortedstuff = []

    i=chnlstart

    while i<chnlend:        
        for traverse in rent:
            if i==string.atoi(traverse[5][:2]):
                complete.append(traverse)
        i=i+1

    #parse list by channels and put into channel sorted list
    tmp = []
    i=0
    
    for traverse in complete:
        tmp.append(traverse)
        if i<len(complete)-1:
            #double test needed to prevent seg fault at the end
            if complete[i][5][:2]!=complete[i+1][5][:2]:
                sortedstuff.append(tmp)
                tmp = []
        i=i+1

    #Sort within each channel for by start time
    for traverse in sortedstuff:
        traverse.sort(lambda x,y: (cmp(x[7],y[7])))
        
    #put out of double list back into single list and return
    for traverse in sortedstuff:
        for trav2 in traverse:
            returnme.append(trav2)

    return returnme

def color(item):
    if item=="News" or item=="Special":
        return "blue"
    elif item=="Sports":
        return "green"
    elif item=="Action":
        return "red"
    elif item=="Soaps" or item=="Reality":
        return "powder blue"
    elif item=="Doc" or item=="Edu":
        return "misty rose"
    elif item=="Health" or item=="Travel":
        return "azure"
    elif item=="Comedy":
        return "yellow"
    elif item=="Talk":
        return "purple"
    elif item=="Children's":
        return "hot pink"
    elif item=="How-To" or item=="Cooking":
        return "coral"
    elif item=="SciFi" or item=="Mystery":
        return "lime green"
    elif item=="Drama" or item=="Crime":
        return "orange"
    elif item=="Shopping" or item=="Collectibles":
        return "aquamarine"
    else:
        return "ForestGreen"

def getday(offset,hoffset):
    mytime = time.localtime()
    hoffset=hoffset+mytime[3]+1
    heffect=(hoffset-hoffset%24)/24 #to account for hours just winding up.
    return "%s/%s/%s" % (mytime[1],mytime[2]+offset+heffect,mytime[0])

def getstarthour(offset):
    mytime=time.localtime()
    return mytime[3]+offset-1

def txtcolor(item):
    global torec
    #check if in database to record
    for traverse in torec:
        if traverse[0]==item[0] and traverse[3]==item[3] and traverse[4]==item[4] and traverse[5]==item[5]:
            return "red"
        #color to return if set to record

    #color to return if not set to record
    return "black"

def inputresponse(input, list, current):
    #Test for starting display, where you're not supposed to display anything.
    if input=="nothing":
        return 0
    elif input=="Up" or input=="Down":
        return 3
    elif input=="Left" or input=="Right":
        return 2


    return 1
