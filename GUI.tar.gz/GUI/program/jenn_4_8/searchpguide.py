#for importing the function to know the local time
import time
#for importing the mysql database
import MySQLdb
#for useful string manipulations
import string

#used to store info on the root
global root

#this is for the width program to truncate the length if the program goes past the current menu

#ending hour for listing being displayed
global endhour
global starthour
global torec
global torec
global resultset
global channels
global seasonpassdbase

#returns width in minutes
def width(program):
    global endhour
    global starthour
    #print "endmin %s startmin %s" % (endhour*60,starthour*60)
    
    endmin=program[10]
    startmin=program[8]

    if endmin>endhour*60:
        endmin=endhour*60

    if startmin<starthour*60:
        startmin=starthour*60
            
    #print "program title %s end hour %s minute %s start hour %s minute %s width %s %s startday" % (program[0],program[9],program[10],program[7],program[8],program[10]-program[8],program[3])

    return endmin-startmin
        

def reload_dbase(): #reloads just the torec and seasonpassdbase
    global seasonpassdbase    
    global torec

    #Connect to the Database
    mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
    #create a cursor
    cursor = mydb.cursor()

    #Load Recorded TV data
    cursor.execute("SELECT * FROM " + "torecord")
    torec=cursor.fetchall()

    #Load SeasonPass
    cursor.execute("SELECT * FROM " + "seasonpass")
    seasonpassdbase=cursor.fetchall()


    
def init_dbase():
    global resultset
    global torec
    global channels
    global seasonpassdbase
    
    channels = []
    #Connect to the Database
    mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
    #create a cursor
    cursor = mydb.cursor()

    #Load Recorded TV data
    cursor.execute("SELECT * FROM " + "torecord")
    torec=cursor.fetchall()

    #Load SeasonPass
    cursor.execute("SELECT * FROM " + "seasonpass")
    seasonpassdbase=cursor.fetchall()
    
    #tells the database to give you all of the programme data
    cursor.execute("SELECT * FROM " + "programme")

    #load the resultset
    resultset = cursor.fetchall()    

    for traverse in resultset:
        test=1
        for checkme in channels:
            if checkme==traverse[5]:
                test=0
        if test==1:
            channels.append(traverse[5])

    #Sort Channel List
    channels.sort(lambda x,y: (cmp(string.atoi(x[0:2]),string.atoi(y[0:2]))))


#returns list of what your searching for
def getprogramdata(aday,ahour,channel):
    global resultset
    global torec
    
    #this is the function to get the local time it's in a list
    mytime = time.localtime()

    #to figure out how many days have passed thus far
    month=mytime[1]
    if month==1:
        days=0
    elif month==2:
        days=31
    elif month==3:
        days=59
    elif month==4:
        days=90        
    elif month==5:
        days=120
    elif month==6:
        days=151
    elif month==7:
        days=181
    elif month==8:
        days=212
    elif month==9:
        days=243
    elif month==10:
        days=273
    elif month==11:
        days=304        
    elif month==12:
        days=334
        
    days=days+mytime[2] + aday
    #print days,
    #print "days so far"

    #calculates number of hours thus far including the offset
    hours=24*days + mytime[3] + ahour

    #print "Hours so Far",
    #print hours

    #print "Minutes so far",
    #print hours*60

    #this variable sets up the number of hours we want to return the results for
    hourswanted=2
    #for width program to truncate the listing

    global endhour
    global starthour
    global torec
    endhour=hourswanted+hours
    starthour=hours
    


    #pull out relavent program data for our day
    #filter out actual channels to save
    rent=[]
    for traverse in resultset:
        #check for if on correct day and is same day
        if (starthour*60<=(traverse[8])<endhour*60) or (starthour*60<(traverse[10])<=endhour*60) or traverse[8]<starthour*60<endhour*60<traverse[10]:
            rent.append(traverse)

    #print rent

    #***** Filter time according to channels we're interested in****
    #this is the starting value for how many channels it will search for

    i=0
    numchtoret=15 #this is the number of channels we want to return 
    returnme = [] #Final List to Return
    complete = [] #List of shows in one channel Channel
    sortedstuff = [] #List Sorted by channel and show

    while i<numchtoret: #loop through each channel we want to return
        for traverse in rent: #Loop through each show and check for valid channel
            if channels[(i+channel)%len(channels)]==traverse[5]: #Check if on channel we're looking for
                complete.append(traverse)
        i=i+1
        #for double list of channels and shows
        sortedstuff.append(complete)
        complete = []

    #Sort within each channel for by start time
    for traverse in sortedstuff:
        traverse.sort(lambda x,y: (cmp(x[7],y[7])))
        
    #put out of double list back into single list and return
    for traverse in sortedstuff:
        for trav2 in traverse:
            returnme.append(trav2)

    return returnme

def color(item):
    if item=="News" or item=="Special":
        return "blue"
    elif item=="Sports":
        return "green"
    elif item=="Action":
        return "red"
    elif item=="Soaps" or item=="Reality":
        return "powder blue"
    elif item=="Doc" or item=="Edu":
        return "misty rose"
    elif item=="Health" or item=="Travel":
        return "azure"
    elif item=="Comedy":
        return "yellow"
    elif item=="Talk":
        return "purple"
    elif item=="Children's":
        return "hot pink"
    elif item=="How-To" or item=="Cooking":
        return "coral"
    elif item=="SciFi" or item=="Mystery":
        return "lime green"
    elif item=="Drama" or item=="Crime":
        return "orange"
    elif item=="Shopping" or item=="Collectibles":
        return "aquamarine"
    else:
        return "ForestGreen"

def getday(offset,hoffset):
    mytime = time.localtime()
    hoffset=hoffset+mytime[3]+1
    heffect=(hoffset-hoffset%24)/24 #to account for hours just winding up.
    return "%s/%s/%s" % (mytime[1],mytime[2]+offset+heffect,mytime[0])

def getstarthour(offset):
    mytime=time.localtime()
    return mytime[3]+offset-1

def txtcolor(item):
    global torec
    #check if in database to record

    for traverse in torec:
        if traverse[0]==item[0] and traverse[3]==item[3] and traverse[4]==item[4] and traverse[5]==item[5]:
            return "red"
        #color to return if set to record

    #color to return if not set to record
    return "black"

def seasonpasscheck(item):
    for traverse in seasonpassdbase:
        #print item[3][8:15]
        if item[0]==traverse[0] and item[5]==traverse[1] and traverse[2]==item[3][8:15]:
            return 1

    return 0
            

def inputresponse(input, currentlist, oldlist, current):
    #Test for starting display, where you're not supposed to display anything.
    if input=="nothing":
        return -1

    if oldlist!=currentlist: #This is the case for where the program menu has changed it's display from the last time, so figuring out the focus may be difficult
        

        #The Person wants to go right and the display has changed
        if input=="Right":
            oldendtime=oldlist[current][10]+2 #find the new start time that is one minute past the old end time
            oldchannel=oldlist[current][5] #make sure it's the correct channel
            i=0
            for traverse in currentlist:
                if traverse[5]==oldchannel and traverse[8]<=oldendtime<=traverse[10]:
                    return i
                i=i+1

            if i>=len(currentlist): #special case for display change, but displaying same show
                i=0
                for traverse in currentlist:
                    if traverse[5]==oldchannel and traverse[8]<=oldendtime-2<=traverse[10]:
                        return i
                    i=i+1
                    
                
        if input=="Left":
            oldendtime=oldlist[current][8]-2 #find the new start time that is one minute past the old end time
            oldchannel=oldlist[current][5] #make sure it's the correct channel
            i=0
            for traverse in currentlist:
                if traverse[5]==oldchannel and traverse[8]<=oldendtime<=traverse[10]:
                    return i
                i=i+1

            if i>=len(currentlist): #special case for display change, but displaying same show
                i=0
                for traverse in currentlist:
                    if traverse[5]==oldchannel and traverse[8]<=oldendtime+2<=traverse[10]:
                        return i
                    i=i+1

        if input=="Down":
            oldendtime=oldlist[current][8]+1


            i=0
            for traverse in channels:
               if traverse==oldlist[current][5]:
                   oldchannel=channels[i+1] #Advance to next channel cuz down
               i=i+1

            i=0
            for traverse in currentlist:
                if traverse[5]==oldchannel and traverse[8]<=oldendtime<=traverse[10]:
               
                    return i
                i=i+1            
        if input=="Up":
            oldendtime=oldlist[current][8]+1

            i=0
            for traverse in channels:
               if traverse==oldlist[current][5]:
                   oldchannel=channels[i-1] #Advance to previous channel cuz up
               i=i+1

            i=0
            for traverse in currentlist:
                if traverse[5]==oldchannel and traverse[8]<=oldendtime<=traverse[10]:
                    return i
                i=i+1       
        return 0

    
    if input=="Down": # ****************************DOWN*****************
        i=current%len(oldlist)

        if current+1>=len(oldlist):
            return (current+1)*-1             
        
        while oldlist[i][5]==oldlist[i+1][5] and i+2<len(oldlist): #while next channel in list is same as the current channel
            i=i+1
        i=i+1
        if i+2>len(oldlist):
            return (current+1)*-1
        
        #Find show one down similar start time
        while oldlist[current][8]>oldlist[i][8] and oldlist[i][5]==oldlist[i+1][5]:
            #Test for if end of list
            if i+1>=len(oldlist):
                return (current+1)*-1
            #increment
            i=i+1
        #print "i is %s len is %s" % (i,len(oldlist))
        return i


    
    elif input=="Up": #**********************************UP****************

        if current==0: #special case for if at start of list
            return (current+1)*-1   

        i=current
        while oldlist[i][5]==oldlist[i-1][5] and i-1>0: #while next channel in list is same as the current channel
            i=i-1
        i=i-1
        if i-1<0:
            return (current+1)*-1
        if i==0:
            return i
        
        #Find show one down similar start time
        while oldlist[current][8]<oldlist[i][8] and oldlist[i][5]==oldlist[i-1][5]:
            #Test for if end of list
            if i-1<0:
                return (current+1)*-1
            #increment
            i=i-1
        #print "i is %s len is %s" % (i,len(oldlist))
        return i



    elif input=="Right": #************************RIGHT********************
        if current+1>=len(oldlist): #We know at's at the end of the list and needs to display a new one
            return (current+1)*-1

        if oldlist[current][5]!=oldlist[current+1][5]:
            return (current+1)*-1
        else:
            return current+1
    elif input=="Left": #*********************************LEFT***********
        if current==0: #It's at the start of the list so we know it needs to go left
            return (current+1)*-1
        
        if oldlist[current][5]!=oldlist[current-1][5]:
            return (current+1)*-1
        else:
            return current-1    
    


    return current
