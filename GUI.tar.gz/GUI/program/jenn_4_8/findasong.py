#for importing all of the tkinter stuff
from Tkinter import *
from tkSimpleDialog import Dialog
import tkMessageBox
#import the program searchguide functionality
import searchpguide
import string
import re
import MySQLdb

def color(item):
    if item=="Rock":
        return "blue"
    elif item=="Jazz":
        return "green"
    elif item=="Ska":
        return "red"
    elif item=="Soul":
        return "powder blue"
    elif item=="Alternative":
        return "misty rose"
    elif item=="Big Band":
        return "azure"
    elif item=="Metal":
        return "yellow"
    elif item=="Instrumental":
        return "purple"
    elif item=="Pop":
        return "hot pink"
    elif item=="Soundtrack":
        return "coral"
    else:
        return "ForestGreen"


#variables for displaying tk stuff
root=Tk()

#this is to store the stuff I'm going to need to display
testashow = []
buttonlist = []
showlist = []

mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
#create a cursor
    
cursor = mydb.cursor()

#tells the database to give you all of the programme data
cursor.execute("SELECT * FROM " + "audio")
#load the resultset
resultset = cursor.fetchall()

def reportEvent(event):
    print event.keysym
    if event.keysym=='q':
        root.destroy()

global resultsframe
resultsframe = Frame(root)
bigtimeframe = Frame(root)

def showsearch(input1, input2):
    global buttonlist
    
    for traverse2 in buttonlist:
        traverse2.destroy()
    buttonlist=[]
    
    #display relavent entries
    for traverse in resultset:
        pattern = ent.get()
        if input1=="nothing":
            matchobj = re.search(pattern, traverse[0])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="title":
            matchobj = re.search(pattern, traverse[0])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="artist":
            matchobj = re.search(pattern, traverse[2])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="album":
            matchobj = re.search(pattern, traverse[3])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="genre":
            matchobj = re.search(pattern, traverse[5])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()
            
    #testashow.sort(lambda x,y: (cmp(x[0],y[0])))
    testashow.sort(lambda x,y: (cmp(x[0],y[0])))

    if input2=='1':
        testashow.sort(lambda x,y: (cmp(x[4],y[4])))
    if input2=='2':
        testashow.sort(lambda x,y: (cmp(x[0],y[0])))
    if input2=='3':
        testashow.sort(lambda x,y: (cmp(x[2],y[2])))
    if input2=='4':
        testashow.sort(lambda x,y: (cmp(x[5],y[5])))
            
    #**************For Input of keystrokes*****************
    root.bind_all('<KeyPress>',reportEvent)

    #variables used internally while traversing all of the shows to display
    i=0
    #display all listing info
    while i<len(testashow) and i<25:
        #put listing info into it's own button
        showbutton = Button(resultsframe,relief=RAISED,
                          bg=color(testashow[i][6]))
        Label(showbutton,text=testashow[i][2]+"-"+testashow[i][0]+
              ", "+testashow[i][3],
              bg=color(testashow[i][5]),
              width=70).pack(side=LEFT)
        timeframe = Frame(bigtimeframe,borderwidth=2,relief=GROOVE)
        Label(timeframe,text=testashow[i][9],
              justify=LEFT,width=5).pack(side=LEFT)
        showbutton.pack(side=TOP,padx=0,pady=0,anchor=NW)
        timeframe.pack(side=TOP,padx=1,pady=1,anchor=NE)
        buttonlist.append(showbutton)
        buttonlist.append(timeframe)
        i = i+1

    bigtimeframe.pack(side=RIGHT,anchor=NE)
    resultsframe.pack(side=RIGHT,anchor=NE)


    x=0
    print len(testashow)


    while x<len(testashow):
        #print x
        #print len(testashow)
        del testashow[x]

variables = []

leftframe = Frame(root)
searchframe = Frame(leftframe)
searchbtnframe = Frame(leftframe)

lab = Label(searchframe,width=16,text='Type pattern here: ')
lab.pack(side=LEFT,anchor=NW)
ent = Entry(searchframe)
ent.pack(side=LEFT,anchor=NW)

var = StringVar()
ent.config(textvariable=var)
variables.append(var)


sortframe = Frame(leftframe)
sortbtnframe = Frame(sortframe)

MODES = [
    ("Year", "1"),
    ("Title", "2"),
    ("Artist", "3"),
    ("Genre", "4"),
    ]
                  
v = StringVar()
v.set("1") # initialize

rdlab = Label(sortframe,width=26,text='Sort results by, or browse by: ')
rdlab.pack(side=LEFT,anchor=NW)

global searchvar
searchvar = "nothing"
print searchvar

def fetch():
    print 'Input => "%s"' % ent.get()
    global searchvar
    searchvar = "title"
    showsearch("title", 0)

def fetchartist():
    print 'Input => "%s"' % ent.get()
    global searchvar
    searchvar = "artist"
    showsearch("artist", 0)

def fetchalbum():
    print 'Input => "%s"' % ent.get()
    global searchvar
    searchvar = "album"
    showsearch("album", 0)

def fetchgenre():
    print 'Input => "%s"' % ent.get()
    global searchvar
    searchvar = "genre"
    showsearch("genre", 0)

def onPress():
    pick = v.get()
    print 'Input2 => "%s"' % ent.get()
    print 'you pressed', pick
    print searchvar
    showsearch(searchvar, pick)
                  
for text, mode in MODES:
    rdbtn = Radiobutton(sortbtnframe,text=text,command=onPress,
                        variable=v,value=mode)
    rdbtn.pack(side=TOP,anchor=NW)

ent.focus()
ent.bind('<Return>',(lambda event: fetch()))
btn = Button(searchbtnframe,text='Search for Title',command=fetch)
btn.pack(side=TOP,anchor=NW,fill=X)
btn = Button(searchbtnframe,text='Search by Artist',command=fetchartist)
btn.pack(side=TOP,anchor=NW,fill=X)
btn = Button(searchbtnframe,text='Search by Album',command=fetchalbum)
btn.pack(side=TOP,anchor=NW,fill=X)
btn = Button(searchbtnframe,text='Search by Genre',command=fetchgenre)
btn.pack(side=TOP,anchor=NW,fill=X)
newvar = StringVar()


searchframe.pack(side=TOP,anchor=NW)
searchbtnframe.pack(side=TOP,anchor=NE)
sortbtnframe.pack(side=TOP,anchor=NW)
sortframe.pack(side=TOP,anchor=NW)
leftframe.pack(side=LEFT,anchor=NW)

#run the program thingy
root.mainloop()
