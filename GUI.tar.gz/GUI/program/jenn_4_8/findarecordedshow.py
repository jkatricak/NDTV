#for importing all of the tkinter stuff
from Tkinter import *
from tkSimpleDialog import Dialog
import tkMessageBox
#import the program searchguide functionality
import searchpguide
import string
import re
import MySQLdb

def color(item):
    if item=="News" or item=="Special":
        return "blue"
    elif item=="Sports":
        return "green"
    elif item=="Action":
        return "red"
    elif item=="Soaps" or item=="Reality":
        return "powder blue"
    elif item=="Doc" or item=="Edu":
        return "misty rose"
    elif item=="Health" or item=="Travel":
        return "azure"
    elif item=="Comedy":
        return "yellow"
    elif item=="Talk":
        return "purple"
    elif item=="Children's":
        return "hot pink"
    elif item=="How-To" or item=="Cooking":
        return "coral"
    elif item=="SciFi" or item=="Mystery":
        return "lime green"
    elif item=="Drama" or item=="Crime":
        return "orange"
    elif item=="Shopping" or item=="Collectibles":
        return "aquamarine"
    else:
        return "ForestGreen"


#variables for displaying tk stuff
root=Tk()

#this is to store the stuff I'm going to need to display
testashow = []
buttonlist = []
showlist = []

mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
#create a cursor
    
cursor = mydb.cursor()

#tells the database to give you all of the programme data
cursor.execute("SELECT * FROM " + "recordedtv")
#load the resultset
resultset = cursor.fetchall()

def reportEvent(event):
    print event.keysym
    if event.keysym=='q':
        root.destroy()

global resultsframe
resultsframe = Frame(root)
bigtimeframe = Frame(root)

def showsearch(input1, input2):
    global buttonlist
    
    for traverse2 in buttonlist:
        traverse2.destroy()
    buttonlist=[]
    
    #display relavent entries
    for traverse in resultset:
        pattern = ent.get()
        if input1=="nothing":
            matchobj = re.search(pattern, traverse[0])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="title":
            matchobj = re.search(pattern, traverse[0])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="sub":
            matchobj = re.search(pattern, traverse[1])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="time":
            if pattern == "1a":
                pattern = "01"
            if pattern == "2a":
                pattern = "02"
            if pattern == "3a":
                pattern = "03"
            if pattern == "4a":
                pattern = "04"
            if pattern == "5a":
                pattern = "05"
            if pattern == "6a":
                pattern = "06"
            if pattern == "7a":
                pattern = "07"
            if pattern == "8a":
                pattern = "08"
            if pattern == "9a":
                pattern = "09"
            if pattern == "10a":
                pattern = "10"
            if pattern == "11a":
                pattern = "11"
            if pattern == "12a":
                pattern = "00"
            if pattern == "1p":
                pattern = "13"
            if pattern == "2p":
                pattern = "14"
            if pattern == "3p":
                pattern = "15"
            if pattern == "4p":
                pattern = "16"
            if pattern == "5p":
                pattern = "17"
            if pattern == "6p":
                pattern = "18"
            if pattern == "7p":
                pattern = "19"
            if pattern == "8p":
                pattern = "20"
            if pattern == "9p":
                pattern = "21"
            if pattern == "10p":
                pattern = "22"
            if pattern == "11p":
                pattern = "23"
            if pattern == "12p":
                pattern = "12"
            matchobj = re.search(pattern, traverse[3][8:10])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()

        elif input1=="genre":
            matchobj = re.search(pattern, traverse[6])
            if matchobj:
                testashow.append(traverse)
                #print traverse
                #print matchobj.start()
            
    #testashow.sort(lambda x,y: (cmp(x[0],y[0])))
    testashow.sort(lambda x,y: (cmp(x[3],y[3])))

    if input2=='1':
        testashow.sort(lambda x,y: (cmp(x[3],y[3])))
    if input2=='2':
        testashow.sort(lambda x,y: (cmp(x[0],y[0])))
    if input2=='3':
        testashow.sort(lambda x,y: (cmp(x[5],y[5])))
    if input2=='4':
        testashow.sort(lambda x,y: (cmp(x[6],y[6])))
            
    #**************For Input of keystrokes*****************
    root.bind_all('<KeyPress>',reportEvent)

    #variables used internally while traversing all of the shows to display
    i=0
    #display all listing info
    while i<len(testashow) and i<25:
        #put listing info into it's own button
        if int(testashow[i][3][8:10])>12:
            apm = "PM"
            if testashow[i][3][8:10]=="13":
                newtime = "01"
            if testashow[i][3][8:10]=="14":
                newtime = "02"
            if testashow[i][3][8:10]=="15":
                newtime = "03"
            if testashow[i][3][8:10]=="16":
                newtime = "04"
            if testashow[i][3][8:10]=="17":
                newtime = "05"
            if testashow[i][3][8:10]=="18":
                newtime = "06"
            if testashow[i][3][8:10]=="19":
                newtime = "07"
            if testashow[i][3][8:10]=="20":
                newtime = "08"
            if testashow[i][3][8:10]=="21":
                newtime = "09"
            if testashow[i][3][8:10]=="22":
                newtime = "10"
            if testashow[i][3][8:10]=="23":
                newtime = "11"
        elif testashow[i][3][8:10]=="00":
            newtime = "12"
            apm = "AM"
        else:
            newtime = testashow[i][3][8:10]
            apm = "AM"
        showbutton = Button(resultsframe,relief=RAISED,
                          bg=color(testashow[i][6]))
        Label(showbutton,text=testashow[i][5]+" "+testashow[i][0]+
              " "+testashow[i][1],
              bg=color(testashow[i][6]),
              width=60).pack(side=LEFT)
        timeframe = Frame(bigtimeframe,borderwidth=2,relief=GROOVE)
        Label(timeframe,text=testashow[i][3][4:6]+"-"+
              testashow[i][3][6:8]+"-"+testashow[i][3][0:4]+" "+newtime+
              ":"+testashow[i][3][10:12]+apm,
              justify=LEFT,width=18).pack(side=LEFT)
        showbutton.pack(side=TOP,padx=0,pady=0,anchor=NW)
        timeframe.pack(side=TOP,padx=1,pady=1,anchor=NE)
        buttonlist.append(showbutton)
        buttonlist.append(timeframe)
        i = i+1

    bigtimeframe.pack(side=RIGHT,anchor=NE)
    resultsframe.pack(side=RIGHT,anchor=NE)


    x=0
    print len(testashow)


    while x<len(testashow):
        #print x
        #print len(testashow)
        del testashow[x]

variables = []

leftframe = Frame(root)
searchframe = Frame(leftframe)
searchbtnframe = Frame(leftframe)

lab = Label(searchframe,width=16,text='Type pattern here: ')
lab.pack(side=LEFT,anchor=NW)
ent = Entry(searchframe)
ent.pack(side=LEFT,anchor=NW)

var = StringVar()
ent.config(textvariable=var)
variables.append(var)


sortframe = Frame(leftframe)
sortbtnframe = Frame(sortframe)

MODES = [
    ("Time", "1"),
    ("Title", "2"),
    ("Channel", "3"),
    ("Genre", "4"),
    ]
                  
v = StringVar()
v.set("1") # initialize

rdlab = Label(sortframe,width=26,text='Sort results by, or browse by: ')
rdlab.pack(side=LEFT,anchor=NW)

global searchvar
searchvar = "nothing"
print searchvar

def fetch():
    print 'Input => "%s"' % ent.get()
    global searchvar
    searchvar = "title"
    showsearch("title", 0)

def fetchsub():
    print 'Input => "%s"' % ent.get()
    global searchvar
    searchvar = "sub"
    showsearch("sub", 0)

def fetchtime():
    print 'Input => "%s"' % ent.get()
    global searchvar
    searchvar = "time"
    showsearch("time", 0)

def fetchgenre():
    print 'Input => "%s"' % ent.get()
    global searchvar
    searchvar = "genre"
    showsearch("genre", 0)

def onPress():
    pick = v.get()
    print 'Input2 => "%s"' % ent.get()
    print 'you pressed', pick
    print searchvar
    showsearch(searchvar, pick)
                  
for text, mode in MODES:
    rdbtn = Radiobutton(sortbtnframe,text=text,command=onPress,
                        variable=v,value=mode)
    rdbtn.pack(side=TOP,anchor=NW)

ent.focus()
ent.bind('<Return>',(lambda event: fetch()))
btn = Button(searchbtnframe,text='Search for Title',command=fetch)
btn.pack(side=TOP,anchor=NW,fill=X)
btn = Button(searchbtnframe,text='Search by Subtitle',command=fetchsub)
btn.pack(side=TOP,anchor=NW,fill=X)
btn = Button(searchbtnframe,text='Search by Time',command=fetchtime)
btn.pack(side=TOP,anchor=NW,fill=X)
btn = Button(searchbtnframe,text='Search by Genre',command=fetchgenre)
btn.pack(side=TOP,anchor=NW,fill=X)
newvar = StringVar()


searchframe.pack(side=TOP,anchor=NW)
searchbtnframe.pack(side=TOP,anchor=NE)
sortbtnframe.pack(side=TOP,anchor=NW)
sortframe.pack(side=TOP,anchor=NW)
leftframe.pack(side=LEFT,anchor=NW)

#run the program thingy
root.mainloop()
