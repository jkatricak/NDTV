#for importing all of the tkinter stuff
from Tkinter import *
#import the program searchguide functionality
import searchpguide

#this is the channel we are currently displaying
onchannel=1
dayoffset=2
houroffset=-12

myresults = searchpguide.getprogramdata(dayoffset,houroffset,onchannel)
maxlen=0
maxtime=0

#print myresults

#display relavent entries
for traverse in myresults:
    print "Start Time %s End Time %s Channel %s Show %s " % (traverse[3], traverse[4], traverse[5],traverse[0])
    print "     Length(Minutes) %s" % (searchpguide.width(traverse)),
    print " Genre %s " % (traverse[6])
    if len(traverse[0]) > maxlen:
        maxlen = len(traverse[0])
        maxlentime = searchpguide.width(traverse)

#print maxlen
#print maxlentime

if maxlen>30:
    maxlen=30
    maxlentime=30

#variables for displaying tk stuff
root=Tk()

#this is to store the channels I'm going to need to display
chnllist = []

#**********display the relavent time information on the top FOR CHANNEL TIME*********
chnllist.append(Frame(root,borderwidth=1,relief=RIDGE))
#display the day on the left part
f=Frame(chnllist[0],borderwidth=2,relief=GROOVE)
Label(f,text=searchpguide.getday(dayoffset),width=10).pack(side=LEFT)
f.pack(side=LEFT,padx=2,pady=2)
#display the hour information
starthinfo = searchpguide.getstarthour(houroffset)
i=0
if (starthinfo-starthinfo%12)/12==1:
    apm="PM"
else:
    apm="AM"

starthinfo=starthinfo%12

while i<4:
    f=Frame(chnllist[0],borderwidth=2,relief=GROOVE)
    Label(f,text="%s:%s0 %s" %(starthinfo+(i-i%2)/2,(i%2)*3, apm),width=28).pack(side=LEFT)
    f.pack(side=LEFT,padx=.6,pady=0)
    i=i+1



#puts the first frame on there
chnllist.append(Frame(root,borderwidth=1,relief=RIDGE))

#variables used internally while traversing all of the shows to display
newchnl=1
i=0

#to display initial channel information
f=Frame(chnllist[newchnl],borderwidth=2,relief=GROOVE)
Label(f,text=myresults[i][5],width=10).pack(side=LEFT)
f.pack(side=LEFT,padx=2,pady=2)
    
#display all listing info
for relief in myresults:
    #put listing info into it's own button
    f=Button(chnllist[newchnl],borderwidth=2,relief=RAISED,bg=searchpguide.color(myresults[i][6]),justify="left")
    # I tweaked with the width thing a lot to try and make it look right, needs to be better
    tmpwidth=searchpguide.width(relief)
    if tmpwidth<len(myresults[i][0]) and tmpwidth>3:
        Label(f,text=myresults[i][0][0:tmpwidth-3]+"...",width=searchpguide.width(relief)-2,bg=searchpguide.color(myresults[i][6])).pack(side=LEFT)
    elif tmpwidth<3:
        Label(f,text=".",width=tmpwidth-2,bg=searchpguide.color(myresults[i][6])).pack(side=RIGHT) 
    else:
        Label(f,text=myresults[i][0],width=searchpguide.width(relief)-2,bg=searchpguide.color(myresults[i][6])).pack(side=RIGHT)
    f.pack(side=LEFT,padx=0,pady=0)

    #if the next channel is different from the current channel put in a new space
    if i<len(myresults)-1:
        #double test needed to prevent seg fault at the end
        if myresults[i][5][:2]!=myresults[i+1][5][:2]:
            #insert the new channel frame into it's own list to refer to later
            chnllist.append(Frame(root,borderwidth=1,relief=RIDGE))
            #this is for referencing the new channel frame when inserting shows
            newchnl=newchnl+1
            #this is for putting in the channel information into the new channel frame
            f=Frame(chnllist[newchnl],borderwidth=2.0,relief=GROOVE)
            Label(f,text=myresults[i+1][5],width=10).pack(side=LEFT)
            f.pack(side=LEFT,padx=2,pady=2)
    i = i+1
    
#actually pack up all of the channel frames to display them on the screen
for traverse in chnllist:
    traverse.pack()

f.focus_set()
        

#run the program thingy
root.mainloop()

#        Label(f,text=myresults[i][0],width=((searchpguide.width(relief)-2)/2)).pack(side=LEFT)
