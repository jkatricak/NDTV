#for importing all of the tkinter stuff
from Tkinter import *
from tkSimpleDialog import Dialog
import tkMessageBox
#import the program searchguide functionality
import searchpguide
import string
import re
import MySQLdb

def color(item):
    if item=="News" or item=="Special":
        return "blue"
    elif item=="Sports":
        return "green"
    elif item=="Action":
        return "red"
    elif item=="Soaps" or item=="Reality":
        return "powder blue"
    elif item=="Doc" or item=="Edu":
        return "misty rose"
    elif item=="Health" or item=="Travel":
        return "azure"
    elif item=="Comedy":
        return "yellow"
    elif item=="Talk":
        return "purple"
    elif item=="Children's":
        return "hot pink"
    elif item=="How-To" or item=="Cooking":
        return "coral"
    elif item=="SciFi" or item=="Mystery":
        return "lime green"
    elif item=="Drama" or item=="Crime":
        return "orange"
    elif item=="Shopping" or item=="Collectibles":
        return "aquamarine"
    else:
        return "ForestGreen"


#this is to store the stuff I'm going to need to display
testashow = []

mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')
#create a cursor
    
cursor = mydb.cursor()

#tells the database to give you all of the programme data
cursor.execute("SELECT * FROM " + "programme")
#load the resultset
resultset = cursor.fetchall()

def reportEvent(event):
    print event.keysym
    if event.keysym=='q':
        root.destroy()

widget = Frame()
#inputpattern = tkSimpleDialog.askstring(None, "Search String: ")

def showsearch(input):
    #display relavent entries
    for traverse in resultset:
        pattern = "Friends"
        matchobj = re.match(pattern, traverse[0])
        if matchobj:
            testashow.append(traverse)
            print traverse
            print matchobj.start()

    testashow.sort(lambda x,y: (cmp(x[3],y[3])))
            
    #**************For Input of keystrokes*****************
    root.bind_all('<KeyPress>',reportEvent)


    #variables used internally while traversing all of the shows to display
    i=0
    #display all listing info
    while i<len(testashow) and i<25:
        print i
        #put listing info into it's own button
        f=Button(widget,borderwidth=2,relief=RAISED,bg=color(testashow[i][6]),justify="left")
        Label(f,text=testashow[i][5]+" "+testashow[i][0]+" "+testashow[i][1],bg=color(testashow[i][6]),width=60).pack(side=LEFT)
        f.pack(side=TOP,padx=0,pady=0)
        i = i+1
        
#variables for displaying tk stuff
root=Tk()

showsearch("nothing")
widget.pack()

#run the program thingy
widget.mainloop()
