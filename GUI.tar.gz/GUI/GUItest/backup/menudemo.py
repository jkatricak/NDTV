#!/usr/local/bin/python
import readsetup
import Tkinter
import ImageTk
import Image

#this is the starting setup file to load and display

readsetup.setupfile="simple/middle.setup"

def reportEvent(event):
    print event.keysym
    if event.keysym=='q':
        readsetup.root.destroy()
        readsetup.quit=0
    readsetup.setupfile=readsetup.input(event.keysym, readsetup.setupfile)
    #readsetup.root.destroy()
    flname = readsetup.display(readsetup.setupfile)[:-4]+".GIF"
    print flname

    readsetup.img=Tkinter.PhotoImage(file=flname)

    tmp=Tkinter.Label(readsetup.root,image=readsetup.img)

    tmp.pack()    
    readsetup.lbl.destroy()
    readsetup.lbl=tmp 
    
#to determine when to quit out of menu's
readsetup.quit = 1

#display the appropriate visual for this setupfile
readsetup.root=Tkinter.Tk()
frame = Tkinter.Frame(readsetup.root,takefocus=1,highlightthickness=2)
text = Tkinter.Entry(frame,width=0,takefocus=1, highlightthickness=0)
#Binding input and output
frame.bind('<KeyPress>', reportEvent)
text.bind('<KeyPress>', reportEvent)
text.pack()
frame.pack()
text.focus_set()

#loop to go through all the stuff
while readsetup.quit:
    
    #display the appropriate visual for this setupfile
    #readsetup.root=Tkinter.Tk()
    #frame = Tkinter.Frame(readsetup.root,takefocus=1,highlightthickness=2)
    #text = Tkinter.Entry(frame,width=10,takefocus=1, highlightthickness=2)
    #Binding input and output
    #frame.bind('<KeyPress>', reportEvent)
    #text.bind('<KeyPress>', reportEvent)
    #text.pack()
    #frame.pack()
    #text.focus_set()

    flname = readsetup.display(readsetup.setupfile)[:-4]+".GIF"
    print flname
    readsetup.img=Tkinter.PhotoImage(file=flname)
    readsetup.lbl=Tkinter.Label(readsetup.root,image=readsetup.img)
    readsetup.lbl.pack()

    readsetup.root.mainloop()
