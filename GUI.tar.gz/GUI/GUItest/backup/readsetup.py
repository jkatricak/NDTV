import string
import Tkinter
import ImageTk
import Image

global setupfile
global root
global quit
global img
global lbl

#*******************for processing the simple styles**********************
def processsimple(inp,fl):

    i=0
    
    #search for start and end response tag
    for traverse in fl:
        if traverse[0] == '<response>':
            startresponse=i
        if traverse[0] == '</response>':
            endresponse=i
        i=i+1

    i=startresponse + 1
    
    while i<endresponse:
        if fl[i][0][:-1]==inp:
            if fl[i][1]=='goto':
                return fl[i][2]
        i=i+1

    if fl[endresponse-1][0][:-1]=='other':
        if fl[endresponse-1][1]=='goto':           
           return fl[endresponse-1][2]     

    print ("ERROR NO INPUT RESPONSE FOUND")
    return "ERROR"
        
    
#***************Function to give the appropriate response to user input******
def input(inp, flname):
    print "Processing setup file " + flname

    #opens the specified file
    input=open(flname,'r')
    
    #sets up a new list for the parsed read in information
    cmd = []

    #reads in the data from the file, parses it by spaces,
    #and removes the \n's from the end of each line.  Result is stored in list
    for line in input.readlines():
        cmd.append(string.split(line[:-1], " "))

    #display parsed results
    #print cmd

    if cmd[0][0]=='Style:':
        if cmd[0][1]=='Simple':
            return processsimple(inp,cmd)
    
    return "ERROR"


#*************Function to Display the graphics for the simple Style***********
def displaysimple(fl):
    i=0
    
    #search for start and end graphics tags
    for traverse in fl:
        if traverse[0] == '<graphics>':
            startgraphics=i
        if traverse[0] == '</graphics>':
            endgraphics=i
        i=i+1

    #traverse through based on starting position
    i=startgraphics+1
    while i<endgraphics:
        #test appropriate section for load image command
        if fl[i][0]=='LoadImage:':
            imageflname=fl[i][1]
        i=i+1

    print "Image Filename to Load is " + imageflname

    
    return imageflname


    


#*********** function for displaying the appropriate stuff on the screen****
def display(flname):

    #opens the specified file
    input=open(flname,'r')
    
    #sets up a new list for the parsed read in information
    cmd = []

    #reads in the data from the file, parses it by spaces,
    #and removes the \n's from the end of each line.  Result is stored in list
    for line in input.readlines():
        cmd.append(string.split(line[:-1], " "))

    if cmd[0][0]=='Style:':
        if cmd[0][1]=='Simple':
            return displaysimple(cmd)

