#!/usr/local/bin/python
import readsetup
import Tkinter
import ImageTk
import Image
from PIL import Image, ImageTk

#this is the starting setup file to load and display

readsetup.setupfile="menudemo/mediavideo.setup"

def reportEvent(event):
    print event.keysym
    if event.keysym=='q':
        readsetup.root.destroy()
        readsetup.quit=0
    readsetup.setupfile=readsetup.input(event.keysym, readsetup.setupfile)
    #readsetup.root.destroy()
    flname = readsetup.display(readsetup.setupfile)[:-4]+".GIF"
    print flname

    readsetup.img=Tkinter.PhotoImage(file=flname)

    tmp=Tkinter.Label(readsetup.root,image=readsetup.img)
    tmp.pack()    
    readsetup.lbl.destroy()
    readsetup.lbl=tmp 
    
#to determine when to quit out of menu's
readsetup.quit = 1

#display the appropriate visual for this setupfile
readsetup.root=Tkinter.Tk()
frame = Tkinter.Frame(readsetup.root,takefocus=1,highlightthickness=2)

#Binding input and output
readsetup.root.bind_all('<KeyPress>', reportEvent)
readsetup.root.overrideredirect(0)
frame.pack()

#loop to go through all the stuff
while readsetup.quit:
    
    #display the appropriate visual for this setupfile
    #readsetup.root=Tkinter.Tk()
    #frame = Tkinter.Frame(readsetup.root,takefocus=1,highlightthickness=2)
    #text = Tkinter.Entry(frame,width=10,takefocus=1, highlightthickness=2)
    #Binding input and output
    #frame.bind('<KeyPress>', reportEvent)
    #text.bind('<KeyPress>', reportEvent)
    #text.pack()
    #frame.pack()
    #text.focus_set()

    w = readsetup.root.winfo_screenwidth()
    h = readsetup.root.winfo_screenheight()
    readsetup.root.overrideredirect(0)
    readsetup.root.geometry("%dx%d+0+0" % (w, h))

    flname = readsetup.display(readsetup.setupfile)[:-4]+".GIF"
    print flname
    readsetup.img=Tkinter.PhotoImage(file=flname)
    readsetup.lbl=Tkinter.Label(readsetup.root,image=readsetup.img)
    readsetup.lbl.pack()

    readsetup.root.mainloop()
