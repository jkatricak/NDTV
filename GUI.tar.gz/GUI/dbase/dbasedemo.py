
#import the database
import MySQLdb

#Connect to the Database
mydb = MySQLdb.Connect(host='localhost', user='ndtv', passwd='mysql', db='ndtv')

#create a cursor
cursor = mydb.cursor()

#figure out which dbase to search
print("Which of the Following Databases do you want to search?")
print("programme")
print("audio")
print("video")
print("pictures")
print("recordedtv")
print("torecord")
print("seasonpass")
dbasechoice = raw_input("=>")

#do a search format is Select FIELD from DBASE
#cursor.execute("SELECT * FROM " + dbasechoice + ",phours where phours.starttime=programme.starttime and phours.channel=programme.channel")
cursor.execute("SELECT * FROM " + dbasechoice)

#Goes through and lists all possible sorting fields
print ("Possible Fields to sort by")

i=0

for search in cursor.description:
    print i,
    print " " + search[0]
    i = i + 1

#sort by a field
#user input input is for numbers, raw_input is for strings
print ("Which field would you like to sort by?")
choice = input("=>")

#load the resultset
resultset = cursor.fetchall()

for traverse in resultset:
    print traverse[choice]
    #print "Title %s StartMinute %s Endminute %s " % (traverse[0],traverse[8],traverse[10])
