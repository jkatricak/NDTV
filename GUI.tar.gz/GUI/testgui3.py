#Program 1: works

import Tkinter
import ImageTk
import Image

root=Tkinter.Tk()
img=Tkinter.PhotoImage(file='right.GIF')
lbl=Tkinter.Label(root,image=img)
lbl.pack()
Tkinter.mainloop()
