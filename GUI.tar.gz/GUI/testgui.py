from Tkinter import *
import Image # Load a couple of PIL
import ImageTk # classes
import os, sys
from string import find, rfind, lower

FILETYPES = ('.gif', '.jpg', '.bmp')

BIG = (768,576); SMALL=(80,60)


class Gui(Frame): # Gui is an extended frame

    def __init__(self, parent=None, path=('.',)):

        try:
            
            files = [] # Create an empty list
            
            for d in path: # path is a tuple of directories
                
                l = os.listdir(d)
                
                f = map(lambda x,y=d:y+delim+x,l)
                
                files = files + f # Concatenate lists

            else:
                
                # Come here if listing fails
                
                print "**Errror**, bad directory: " + d
                
                sys.exit(1)
                
                gifs = filter(lambda x: lower(x[len(x)-4]) in FILETYPES, files)
                
                # Initialize inherited frame
                
                Frame.__init__(self, parent, relief=SUNKEN, bd=2)
                
                self.pack()

                self.image = {} # Dictionary for images
                
                row = col = 0 # For use with grid method
                
                # Next we shall loop over the GIF files and try to read each one
                
                
                for giffile in gifs: # Loop over graphics files
                    
                    # Extract file name
                    
                    gif = giffile[rfind(giffile,DELIM)+1:] # Search from right
                    
                    # Exclude duplicate images
                    
                    if not self.image.has_key(gif):
                        
                        print "Reading ", gif, # Note comma to suppress NL
                        
                        # Read GIF file and create image
                        
                        try:
                            
                            ig = Image.open(giffile)
                            
                            ig.thumbnail(BIG)
                            
                            self.image[gif] = ImageTk.PhotoImage(ig)
                            
                            ig.thumbnail(SMALL) # 80 x 60 pixels
                            
                            b = Button(self, image=ImageTk.PhotoImage(ig),
                                       
                                       command=lambda s=self, x=gif: s.display(x))
                            
                            b.grid(row=row, column=col, sticky=N+S+E+W)
                            
                            col = col + 1 # Update column number
                            
                            if col == 5:
                                
                                row = row + 1 # Update row number
                                
                                col = 0
                                
                                print "" # Complete print statement
                                
                            else: # associated with Try (see part 3)
                                
                                print "*** FAILED *** " 
                                
                                
                                
                                # Method to display full image
                                
                                def display(self, gif):
                                    
                                    top = Toplevel()
                                    top.title(gif)
                                    
                                    top.iconname(gif)
                                    
                                    Label(top,image=self.image[gif]).pack()
                                    
                                    
                                    if __name__ == '__main__':
                                        
                                        if not sys.argv[1:]: 
                                            path = '.'
                                            
                                        else:
                                            
                                            path = sys.argv[1:] 
                                            root = Tk()
                                            root.title('Graphics Browser')
                                            
                                            Gui(root, path).mainloop() # Enter event loop
