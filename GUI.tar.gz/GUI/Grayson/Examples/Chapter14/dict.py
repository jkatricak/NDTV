
class Dictionary:
    def __init__(self, name=None):

        self.dictionary = {
            'Graham Chapman':   (1941, 1989, 'Leicester', 'Medicine'),
            'John Cleese':      (1939, -1, 'Weston-Super-Mare', 'Law'),
            'Eric Idle':        (1943, -1, 'South Shields', 'English'),
            'Terry Jones':      (1942, -1, 'Colwyn Bay', 'English'),
            'Michael Palin':    (1943, -1, 'Sheffield', 'History'),
            'Terry Gilliam':    (1940, -1, 'Minneapolis', 'Political Science'),
            }

