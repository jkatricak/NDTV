from Tkinter import *
from tkSimpleDialog import Dialog
import tkMessageBox
import os
import string

def init_ripcd(frame, args):
    global bitrate
    bitrate = args[0]

    cursor = ['gray', 'gray']
    # determine which button has cursor
    if args[1] == 1:
        cursor[1] = 'yellow'
    else:
        cursor[0] = 'yellow'
    
    fm = Frame(frame) #Frame(root)
    Label(fm, text='Ripping CD at %s kbps' % (bitrate)).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    fm.pack(side=TOP, fill=BOTH, expand=YES, ipady=120)

    fm2 = Frame(frame)
    Label(fm2, text='OK', relief = RAISED, bg = cursor[0]).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    Label(fm2, text='Change', relief = RAISED, bg = cursor[1]).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    fm2.pack(side=TOP, fill=BOTH, expand=YES)

def keyinput(key, arg):
    global bitrate
    tmpreturn = []

    if key=='Return' and arg==0:
        os.system("perl /home/ndtv/DBGroup/ripit.pl --bitrate %s &" % (bitrate))
        tmpreturn.append("Done")
        tmpreturn.append(" ")
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Return' and arg==1:
        argument = "setupscreen"
        tmpreturn.append("GotoFunc")
        tmpreturn.append(argument)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Right' and arg==0:
        argument = 1
        tmpreturn.append("Continue")
        tmpreturn.append(argument)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Left' and arg==0:
        argument = 1
        tmpreturn.append("Continue")
        tmpreturn.append(argument)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Right' and arg==1:
        argument = 0
        tmpreturn.append("Continue")
        tmpreturn.append(argument)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Left' and arg==1:
        argument = 0
        tmpreturn.append("Continue")
        tmpreturn.append(argument)
        tmpreturn.append(" ")
        return tmpreturn
    
