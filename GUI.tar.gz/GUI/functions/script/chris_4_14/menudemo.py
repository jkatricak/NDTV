#!/usr/local/bin/python
import readsetup
import Tkinter
import ImageTk
import Image
from PIL import Image, ImageTk


def keyinput(key):
    #print " Menudemoscript key %s" % (key)
   
    if key=='q':
        readsetup.root.destroy()
        readsetup.quit=0
    myresponse=readsetup.input(key, readsetup.setupfile)
    if (myresponse[:4]=="func"):
        #print "Need to goto a function"
        tmpreturn = []
        tmpreturn.append("GotoFunc")
        tmpreturn.append(myresponse[5:])
        tmpreturn.append(" ")
        return tmpreturn
    ##############################
    elif (myresponse == "setupscreen"):
        tmpreturn = []
        tmpreturn.append("GotoFunc")
        tmpreturn.append(myresponse)
        tmpreturn.append(" ")
        return tmpreturn
    ##############################
    else:
        readsetup.setupfile="/home/ndtv/GUI/functions/script/" + myresponse
    #readsetup.root.destroy()
    flname = readsetup.display(readsetup.setupfile)[:-4]+".GIF"
    #print flname

    readsetup.img=Tkinter.PhotoImage(file="/home/ndtv/GUI/functions/script/" + flname)

    tmp=Tkinter.Label(readsetup.root,image=readsetup.img)
    tmp.pack()    
    readsetup.lbl.destroy()
    readsetup.lbl=tmp
    return "Continue"


#argument 0 - setupfilename to load 
    
def init_script(frameref, arguments):

    #this is the starting setup file to load and display

    readsetup.setupfile=arguments[0]
    
    #to determine when to quit out of menu's
    readsetup.quit = 1

    #display the appropriate visual for this setupfile
    readsetup.root=frameref

    #w = readsetup.root.winfo_screenwidth()
    #h = readsetup.root.winfo_screenheight()
    #readsetup.root.overrideredirect(0)
    #readsetup.root.geometry("%dx%d+0+0" % (w, h))
    
    flname = readsetup.display(readsetup.setupfile)[:-4]+".GIF"
    #print flname
    readsetup.img=Tkinter.PhotoImage(file="/home/ndtv/GUI/functions/script/" + flname)
    readsetup.lbl=Tkinter.Label(readsetup.root,image=readsetup.img)
    readsetup.lbl.pack()
    
    
