from Tkinter import *
from tkSimpleDialog import Dialog
import tkMessageBox
import os
import string

def init_inetradio(frame, arglist, arg1):

    arger = "mplayer " + arglist[arg1] + " &"
    #os.system("./killall mplayer")
    #os.system(arger)
   
    fm = Frame(frame) #Frame(root)
    Label(fm, text='Currently listening to %s' % (arglist[arg1]), font=(('MS'),'48','bold')).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    fm.pack(side=TOP, fill=BOTH, expand=YES, ipady=120)

    #fm2 = Frame(frame)
    #Label(fm2, text='Back', relief = RAISED, font=(('MS'),'48','bold'), ).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    #fm2.pack(side=TOP, fill=BOTH, expand=YES)

    os.system("killall mplayer")
    os.system(arger)
def keyinput(key, arg):

    tmpreturn = []

   
    os.system("killall mplayer")
   

    if key=='Return':
        tmpreturn.append("Done")
        tmpreturn.append(" ")
        tmpreturn.append(arg)
        return tmpreturn
    elif key=='Up':
        arg+=1
        if(arg > 1):
            arg = 0
        tmpreturn.append("Continue")
        tmpreturn.append(arg)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Down':
        arg-=1
        if(arg < 0):
            arg = 1
        tmpreturn.append("Continue")
        tmpreturn.append(arg)
        tmpreturn.append(" ")
        return tmpreturn

