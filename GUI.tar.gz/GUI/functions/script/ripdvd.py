from Tkinter import *
from tkSimpleDialog import Dialog
import tkMessageBox
import popen2
import os
import string

def init_ripdvd(frame,args) :

    id = args[0]
    
    cursor = ['gray', 'gray']
    # determine which button has cursor
    if args[1] == 1:
        cursor[1] = 'yellow'
    else:
        cursor[0] = 'yellow'
    
    #get filename
    global title, foo, bar
    title,foo,bar = popen2.popen3("/home/ndtv/src/DVDtitle/dvdtitle")
    title = title.readlines() # get stdout from dvdtitle
    title = string.replace("%s" % (title),'[\'','')    # chop off
    title = string.replace("%s" % (title),'\\n\']','') # extra characters
    title = title + ".avi" # add file extension
    title = "/ndtv/movies/" + title
    
    fm = Frame(frame) #Frame(root)
    Label(fm, text='Ripping DVD Title %s to file: %s' % (id,title)).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    fm.pack(side=TOP, fill=BOTH, expand=YES, ipady=120)

    fm2 = Frame(frame) #Frame(root)
    Label(fm2, text='OK', relief = RAISED, bg = cursor[0]).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    Label(fm2, text='Change', relief = RAISED, bg = cursor[1]).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    fm2.pack(side=TOP, fill=BOTH, expand=YES)

def keyinput(key, args):
    global title
    tmpreturn = []
    arguments = [1,0]
    arguments[0] = args[0]

    if key=='Return' and args[1]==0:
        os.system("/ndtv/scripts/ndtv_dvd_rec %s %s &" % (args[0],title))
        #add to database
        os.system("perl /home/ndtv/DBGroup/dvdin.pl %s &" % (title))
        tmpreturn.append("Done")
        tmpreturn.append(" ")
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Return' and args[1]==1:
        tmpreturn.append("GotoFunc")
        tmpreturn.append("setupscreen")
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Right' and args[1]==0:
        arguments[1] = 1
        tmpreturn.append("Continue")
        tmpreturn.append(arguments)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Left' and args[1]==0:
        arguments[1] = 1
        tmpreturn.append("Continue")
        tmpreturn.append(arguments)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Right' and args[1]==1:
        arguments[1] = 0
        tmpreturn.append("Continue")
        tmpreturn.append(arguments)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Left' and args[1]==1:
        arguments[1] = 0
        tmpreturn.append("Continue")
        tmpreturn.append(arguments)
        tmpreturn.append(" ")
        return tmpreturn
