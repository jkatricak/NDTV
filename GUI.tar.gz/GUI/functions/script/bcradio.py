from Tkinter import *
from tkSimpleDialog import Dialog
import tkMessageBox
import os
import string

def init_bcradio(frame, arg):

    os.system("/ndtv/scripts/ndtv_radio_off")
    os.system("/ndtv/scripts/ndtv_radio_on")
    os.system("/ndtv/scripts/ndtv_radio_set %s" % (arg*100))
   
    fm = Frame(frame) #Frame(root)
    Label(fm, text='Currently listening to %s' % (arg)).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    fm.pack(side=TOP, fill=BOTH, expand=YES, ipady=120)

    fm2 = Frame(frame)
    Label(fm2, text='Back', relief = RAISED).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    fm2.pack(side=TOP, fill=BOTH, expand=YES)

def keyinput(key, arg):

    tmpreturn = []

    if key=='Return':
        tmpreturn.append("Done")
        tmpreturn.append(" ")
        tmpreturn.append(arg)
        return tmpreturn
    elif key=='Up':
        arg+=2
        tmpreturn.append("Continue")
        tmpreturn.append(arg)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Down':
        arg-=2
        tmpreturn.append("Continue")
        tmpreturn.append(arg)
        tmpreturn.append(" ")
        return tmpreturn

