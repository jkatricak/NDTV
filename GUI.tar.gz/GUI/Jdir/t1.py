from Tkinter import *
import t2

posx = 1
posy = 3
piclist = []
cnvslist = []
max = 0 
btnlist = [[0,-1], [0, -1], [0, 0], [0, -1]]
imglist = [[["mediatitle", "mediatitle"],["gbuttonoff", "gbutton"]],[["videooff", "videoon"],["jumpoff", "jumpon"]],[["audiooff", "audioon"], ["setupoff", "setupon"]],[["imagesoff", "imageson"],["gbuttonoff", "gbutton"]]]

def reportEvent(event):
    global posy
    global posx
    
    
    if event.keysym == 'Down' and posy < 3:
        posy = posy + 1
    elif event.keysym == 'Up' and posy > 1:
        posy = posy - 1
    elif event.keysym == 'Left' and posx > 0:
        posx = posx - 1
    elif event.keysym == 'Right' and posx < 1:
        posx = posx + 1
    if btnlist[posy][posx] == -1 and posx == 1:
        posx = posx - 1
    if btnlist[posy][posx] == -1 and posy > 0:
        posy = posy - 1
    
    displayit()


def displayit():
    global posy
    global posx
    global max
    
    max = 0

    test = []

    frm0 = Frame(root, borderwidth = 0)
    frm1 = Frame(root, borderwidth = 0)
    frm2 = Frame(root, borderwidth = 0)
    frm3 = Frame(root, borderwidth = 0)
    
    
    for i in range(4):
        for j in range(2):
            print posx
            print posy
            print ""
            if btnlist[i][j] > -1:
                if i == posy and j == posx:
                    btnlist[i][j] = 1
                else:
                    btnlist[i][j] = 0
                
                fname = imglist[i][j][btnlist[i][j]]
                piclist.append(PhotoImage(file='/home/ndtv/GUI/Jdir/gphics/' + fname + '.gif'))
                if i == 0:
                    cnvslist.append(Canvas(frm0, width=320, height = 120, borderwidth = 0))
                elif i == 1:
                    cnvslist.append(Canvas(frm1, width=320, height = 120, borderwidth = 0))
                elif i == 2:
                    cnvslist.append(Canvas(frm2, width=320, height = 120, borderwidth = 0))
                elif i == 3:
                    cnvslist.append(Canvas(frm3, width=320, height = 120, borderwidth = 0))
                cnvslist[max].create_image(0, 0, image=piclist[max], anchor = NW)
                cnvslist[max].pack(side = LEFT, expand = YES, ipady = 0)

                max = max + 1
                
    frm0.pack(side = TOP, ipady = 0)
    frm1.pack(side = TOP, ipady = 0)
    frm2.pack(side = TOP, ipady = 0)
    frm3.pack(side = TOP, ipady = 0)

root = Tk()
root.bind_all('<KeyPress>', reportEvent)
root.title('Gimme a display')
#root.geometry("640x480")
displayit()

root.mainloop()

