from Tkinter import *
import t2

t2.posx = 0
t2.posy = 0
t2.piclist = []
t2.cnvslist = []


btnlist = [[0, 0], [0, 0], [0, -1]]
imglist = [[["gbuttonoff", "gbutton"],["gbuttonoff", "gbutton"]], [["gbuttonoff", "gbutton"],["gbuttonoff", "gbutton"]],
[["gbuttonoff", "gbutton"],["gbuttonoff", "gbutton"]]]

def reportEvent(event):
    print event.keysym
    if event.keysym == "down" and posy < 2:
        posy = posy + 1


t2.go = 1

t2.root = Tk()
t2.root.title('Gimme a display')
t2.root.geometry("640x480")

    


mainframe = Frame(t2.root)
ttlframe = Frame(mainframe)
mainpic = PhotoImage(file='/home/ndtv/GUI/Jdir/gphics/gbutton.GIF')
cnvs = Canvas(ttlframe, width=320, height = 120, borderwidth = 0)
cnvs.create_image(0, 0, image=mainpic, anchor=NW)
cnvs.pack( ipady = 0)

frm1 = Frame(mainframe, borderwidth = 0)
frm2 = Frame(mainframe, borderwidth = 0)
frm3 = Frame(mainframe, borderwidth = 0)

print posy

for i in range(3):
    for j in range(2):
        
        if btnlist[i][j] > -1:
            if i == t2.posy and j == t2.posx:
                btnlist[i][j] = 1
            else:
                btnlist[i][j] = 0
                
            fname = imglist[i][j][btnlist[i][j]]
            t2.piclist.append(PhotoImage(file='/home/ndtv/GUI/Jdir/gphics/' + fname + '.GIF'))
                
            if i == 0:
                t2.cnvslist.append(Canvas(frm1, width=320, height = 120, borderwidth = 0))
            elif i == 1:
                t2.cnvslist.append(Canvas(frm2, width=320, height = 120, borderwidth = 0))
            elif i == 2:
                t2.cnvslist.append(Canvas(frm3, width=320, height = 120, borderwidth = 0))
            t2.cnvslist[(i*2)+j].create_image(0, 0, image=t2.piclist[(i*2)+j], anchor = NW)
            t2.cnvslist[(i*2)+j].pack(side = LEFT, expand = YES, ipady = 0)
                
                
ttlframe.pack(side = TOP, ipady = 0)
frm1.pack(side = TOP, ipady = 0)
frm2.pack(side = TOP, ipady = 0)
frm3.pack(side = TOP, ipady = 0)
mainframe.pack()


t2.root.bind_all('<KeyPress>', reportEvent)

t2.root.mainloop()

