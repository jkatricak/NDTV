from Tkinter import *


global posx
global posy
global go
global btnlist
global imglist
global root
global piclist
global cnvslist

