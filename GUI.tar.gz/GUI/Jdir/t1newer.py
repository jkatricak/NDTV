from Tkinter import *
import t2

posx = 0
posy = 0
piclist = []
cnvslist = []
btnlist = [[0, 0], [0, 0], [0, -1]]
imglist = [[["gbuttonoff", "gbutton"],["gbuttonoff", "gbutton"]], [["gbuttonoff", "gbutton"],["gbuttonoff", "gbutton"]],
[["gbuttonoff", "gbutton"],["gbuttonoff", "gbutton"]]]

def reportEvent(event):
    global posy
    global posx
    
    if event.keysym == 'Down' and posy < 2:
        posy = posy + 1
    elif event.keysym == 'Up' and posy > 0:
        posy = posy - 1
    elif event.keysym == 'Left' and posx > 0:
        posx = posx - 1
    elif event.keysym == 'Right' and posx < 1:
        posx = posx + 1
    if btnlist[posy][posx] == -1 and posx == 1:
        posx = posx - 1
    if btnlist[posy][posx] == -1 and posy > 0:
        posy = posy - 1

    displayit()

def displayit():
    global posy
    global posx
    
    #mainframe = Frame(root)    
    
    ttlframe = Frame(root)
    
    mainpic = PhotoImage(file='/home/ndtv/GUI/Jdir/gphics/gbutton.GIF')
    cnvs = Canvas(ttlframe, width=320, height = 120, borderwidth = 0)
    cnvs.create_image(0, 0, image=mainpic, anchor=NW)
    cnvs.pack()
    ttlframe.pack(side = TOP, ipady = 0)

    frm1 = Frame(root, borderwidth = 0)
    frm2 = Frame(root, borderwidth = 0)
    frm3 = Frame(root, borderwidth = 0)
    
    
    for i in range(3):
        for j in range(2):
  
            if btnlist[i][j] > -1:
                if i == posy and j == posx:
                    btnlist[i][j] = 1
                else:
                    btnlist[i][j] = 0
                
                fname = imglist[i][j][btnlist[i][j]]
                piclist.append(PhotoImage(file='/home/ndtv/GUI/Jdir/gphics/' + fname + '.GIF'))
            
                if i == 0:
                    cnvslist.append(Canvas(frm1, width=320, height = 120, borderwidth = 0))
                elif i == 1:
                    cnvslist.append(Canvas(frm2, width=320, height = 120, borderwidth = 0))
                elif i == 2:
                    cnvslist.append(Canvas(frm3, width=320, height = 120, borderwidth = 0))
                cnvslist[(i*2)+j].create_image(0, 0, image=piclist[(i*2)+j], anchor = NW)
                cnvslist[(i*2)+j].pack(side = LEFT, expand = YES, ipady = 0)
                
                
    
    frm1.pack(side = TOP, ipady = 0)
    frm2.pack(side = TOP, ipady = 0)
    frm3.pack(side = TOP, ipady = 0)

root = Tk()
root.bind_all('<KeyPress>', reportEvent)
root.title('Gimme a display')
root.geometry("640x480")
displayit()

root.mainloop()

