from Tkinter import *
import Image # Load a couple of PIL
import ImageTk # classes
import os, sys
from string import find, rfind, lower

FILETYPES = ('.gif', '.jpg', '.bmp')

Frame.__init__(self, parent, relief=SUNKEN, bd=2) 
    
self.pack()

self.image = {} # Dictionary for images

row = col = 0 # For use with grid method


gif ='test.jpg'

ig = Image.open(gif)

self.image[gif] = ImageTk.PhotoImage(ig)

b = Button(self, image=ImageTk.PhotoImage(ig),
           
           command=lambda s=self, x=gif: s.display(x))

b.grid(row=row, column=col, sticky=N+S+E+W)



# Method to display full image

def display(self, gif):
    
    top = Toplevel()
    top.title(gif)
    
    top.iconname(gif)
    
    Label(top,image=self.image[gif]).pack()
    
    path = sys.argv[1:] 
    root = Tk()
    root.title('Graphics Browser')
    
    self.mainloop() # Enter event loop
    
        
