#for importing all of the tkinter stuff
from Tkinter import *
import os

import string

def tv_input(key):
    if key=="q":
        tmpreturn = []
        tmpreturn.append("Done")
        tmpreturn.append(" ")
        tmpreturn.append("Nothing")
        return tmpreturn
    else:
        return "Continue"

def init():
    os.system("/ndtv/scripts/ndtv_tv &")
