#for importing all of the tkinter stuff
from Tkinter import *

import string

def tv_input(key):
    if key=="q":
        tmpreturn = []
        tmpreturn.append("Done")
        tmpreturn.append(" ")
        tmpreturn.append("Nothing")
        return tmpreturn
    else:
        return "Continue"
