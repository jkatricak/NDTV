#for importing all of the tkinter stuff
from Tkinter import *
import sys
sys.path.append("/home/ndtv/GUI/functions/script")
import menudemo
###################
sys.path.append("/home/ndtv/GUI/master/jdir")
import setupscrn
###################

#This is for a reference for which txt means which function to call
# "script" - this is for the scriptable higher level menu stuff

global functionlist
global masterroot
global currentframe

####################
global recSettings

recSettings = [[1, 0, 0], [1, 0, 0], [1, 0, 0], [0, 0, 0], [0, 0, 0]]
####################

functionlist = [] #This list is to store what functions to call
functionlist.append("script") #for the initial call

def reportEvent(event): # for analyzing keyboard input and then passing it onto a given function where appropriate
    global functionlist

    ########################################################
    global recSettings
    global currentframe
    ########################################################

    print event.keysym
    print len(functionlist)-1
    
    if functionlist[len(functionlist)-1]=="script":
        print "Pass info to script"
        result = menudemo.keyinput(event.keysym)
        print result
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
    ###############################################################
    elif functionlist[len(functionlist)-1]=="setupscreen":
        
        result = setupscrn.keyinput(event.keysym, recSettings)
        recSettings = result[1]
        currentframe.destroy() 
        currentframe = Frame(masterroot,borderwidth=1,relief=FLAT)
        setupscrn.init_setupmod(currentframe,recSettings)
        currentframe.pack()
        if result!="Continue":
            returncontrol(result[0],result[1],result[2])
    ###############################################################

def returncontrol(status, nextfunc, argument): # This is for a function to return control and then either add a new function to the list, or return to the lower level stuff.  
    ################################################################
    global recSettings
    ################################################################

    global currentframe
    if status=="Done": #Returns control to the lower level
        print "Done"

    elif status=="GotoFunc":
        print "Goto Function %s" % (nextfunc)
        currentframe.destroy() # need to erase whats there right now, because we will be passing a new frame to the next function
        currentframe = Frame(masterroot,borderwidth=1,relief=FLAT)

        if nextfunc=="script":
            functionlist.append("script")
            menudemo.init_script(currentframe,argument)
        ########################################################################
        elif nextfunc == "setupscreen":
            functionlist.append("setupscreen")
            setupscrn.init_setupmod(currentframe,recSettings)
        ########################################################################
        currentframe.pack()

        
masterroot = Tk() # This is the actual Root reference.  No function should ever get to see this!

currentframe = Frame(masterroot,borderwidth=1,relief=FLAT)

#**************For Input of keystrokes*****************
masterroot.bind_all('<KeyPress>',reportEvent)

w = masterroot.winfo_screenwidth()
h = masterroot.winfo_screenheight()
masterroot.overrideredirect(0)
masterroot.geometry("%dx%d+0+0" % (w, h))

tmpargpass = []
tmpargpass.append("/home/ndtv/GUI/functions/script/menudemo/mediavideo.setup")
returncontrol("GotoFunc","script",tmpargpass)

#menudemo.init_script(masterroot,tmpargpass)




masterroot.mainloop() # Start running it

