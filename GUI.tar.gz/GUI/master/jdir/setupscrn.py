from Tkinter import *

def init_setupmod(mainFrame, arguments):

    selected = [[RAISED, RAISED, RAISED], [RAISED, RAISED, RAISED]]
    cursor = [['gray', 'gray', 'gray'], ['gray', 'gray', 'gray'], ['gray', 'gray', 'gray']]
    
    for x in [0, 1, 2]:
        if arguments[0][x] == 1:
            selected[0][x] = SUNKEN
        if arguments[1][x] == 1:
            selected[1][x] = SUNKEN
        if arguments[2][x] == 1:
            cursor[0][x] = 'yellow'
        elif arguments[3][x] == 1:
            cursor[1][x] = 'yellow'
        elif arguments[4][x] == 1:
            cursor[2][1] = 'yellow'

    
    #root = mainFrame
    fm = Frame(mainFrame, width = 600, height = 100) #Frame(root)
    #Label(fm, text='Video Record Quality:').pack(side=LEFT)
    #fill = X
    #Label(fm, text='Low', relief = selected[0][0], bg = cursor[0][0], width=20, height=5, font=(('MS'),'35','bold')).pack(side=LEFT, anchor=W, expand=YES)
    #Label(fm, text='Medium', relief = selected[0][1], bg = cursor[0][1], width=20, height=5, font=(('MS'),'35','bold')).pack(side=LEFT, anchor=W, expand=YES)
    #Label(fm, text='High', relief = selected[0][2], bg = cursor[0][2], width=20, height=5, font=(('MS'),'35','bold')).pack(side=LEFT, anchor=W, expand=YES)

    #JPK
    Label(fm, text='DVD Title:').pack(side=LEFT)
    #fill = X
    Label(fm, text='1', relief = selected[0][0], bg = cursor[0][0], width=20, height=5, font=(('MS'),'35','bold')).pack(side=LEFT, anchor=W, expand=YES)
    Label(fm, text='2', relief = selected[0][1], bg = cursor[0][1], width=20, height=5, font=(('MS'),'35','bold')).pack(side=LEFT, anchor=W, expand=YES)
    Label(fm, text='3', relief = selected[0][2], bg = cursor[0][2], width=20, height=5, font=(('MS'),'35','bold')).pack(side=LEFT, anchor=W, expand=YES)
    fm.pack(side=TOP, fill=BOTH, expand=YES)

    fm2 = Frame(mainFrame, width = 600, height = 100) 
    Label(fm2, text='Audio Record Settings:').pack(side=LEFT, anchor=W)
    Label(fm2, text='Low', relief = selected[1][0], bg = cursor[1][0], width=20, height=5, font=(('MS'),'35','bold')).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    Label(fm2, text='Medium', relief = selected[1][1], bg = cursor[1][1], width=20, height=5, font=(('MS'),'35','bold')).pack(side=LEFT, anchor=W, fill=X, expand=YES)
    Label(fm2, text='High', relief = selected[1][2], bg = cursor[1][2], width=20, height=5, font=(('MS'),'35','bold')).pack(side=LEFT, anchor=W, fill=X, expand=YES)      
    fm2.pack(side=TOP, fill=BOTH, expand=YES)
    
    #fm3 = Frame(mainFrame)
    #Label(fm3, text='(back)', relief = RAISED, bg = cursor[2][1], width=10, height=5).pack(side=TOP, expand = NO)
    #fm3.pack(side=TOP)

def keyinput(key, arguments):
    tmpreturn = []

    for x in [2, 3, 4]:
        for y in [0, 1, 2]:
            if arguments[x][y] == 1:
                j = x
                k = y 
    
    if key=='Return' and j==4:
        tmpreturn.append("Done")
        tmpreturn.append(" ")
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Right' and k < 2:  
        arguments[j][k] = 0
        k = k + 1
        arguments[j][k] = 1
        tmpreturn.append("Continue")
        tmpreturn.append(arguments)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Left' and k > 0:
        arguments[j][k] = 0
        k = k - 1
        arguments[j][k] = 1
        tmpreturn.append("Continue")
        tmpreturn.append(arguments)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Down' and j < 3:
        arguments[j][k] = 0
        j = j + 1
        arguments[j][k] = 1
        tmpreturn.append("Continue")
        tmpreturn.append(arguments)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Up' and j > 2:
        arguments[j][k] = 0
        j = j - 1
        arguments[j][k] = 1
        tmpreturn.append("Continue")
        tmpreturn.append(arguments)
        tmpreturn.append(" ")
        return tmpreturn
    elif key=='Return' and j < 4:
        for x in [0, 1, 2]:
            arguments[j-2][x] = 0
        arguments[j-2][k] = 1
        tmpreturn.append("Continue")
        tmpreturn.append(arguments)
        tmpreturn.append(" ")
        return tmpreturn
    else:
        tmpreturn.append("Continue")
        tmpreturn.append(arguments)
        tmpreturn.append(" ")
        return tmpreturn
        
