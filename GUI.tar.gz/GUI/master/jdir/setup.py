import Tkinter
import ImageTk
import Image
from PIL import Image, ImageTk

def init_setupmod(mainFrame, arguments):
    print "HITME"
    root = mainFrame
    fm = Frame(root)
    Button(fm, text='Top').pack(side=TOP, anchor=W, fill=X, expand=YES)
    Button(fm, text='Center').pack(side=TOP, anchor=W, fill=X, expand=YES)
    Button(fm, text='Bottom').pack(side=TOP, anchor=W, fill=X, expand=YES)
    fm.pack(side=LEFT, fill=BOTH, expand=YES)
    
def keyinput(key):
    print "HITMEAGAIN"
    tmpreturn = []
    if key=='b':
        tmpreturn.append("Done")
        return tmpreturn
    else:
        tmpreturn.append("Continue")
        
