import Tkinter
import Image
import ImageTk

root = Tkinter.Tk()                                                        
root.title("To Be Displayed on TV")
canvas = Tkinter.Canvas(root,width=640, height=480)      
#self.canvas = Tkinter.Canvas(parent,width=700,height=500)
#self.canvas.pack()
canvas.pack()
myimage=Image.open("test.jpg")
myimage.thumbnail((640,480))
mytkimage = ImageTk.PhotoImage(myimage)
canvas.create_image(0,0,image=mytkimage,anchor='nw')


#self.image = Image.open("001229_1106_charlotteAmalie3.jpg")
#self.tkim = ImageTk.PhotoImage(self.image)
#self.item = self.canvas.create_image(0,0,image=self.tkim,anchor='nw')

root.mainloop()
