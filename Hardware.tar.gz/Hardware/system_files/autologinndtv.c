int main() {
	execlp( "login", "login", "-f", "ndtv", 0);
}
